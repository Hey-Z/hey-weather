
# 从metabase下载数据
## 从labelresult_image_bevod这个表中下载数据
python download_files.py --tabel_name labelresult_image_bevod --condition "batch_id = '110' and sensor_count >= 7 and update_time >= date('2024-01-09')" --save_dir /clever/pvc-volumes/pvc-cephfs-finfs-100t/zhuhuiping/dataset/autopcdet_demo/raw_data

## 从labelresult_image_bevod_autofix这个表中下载数据
python download_files.py --tabel_name labelresult_image_bevod_autofix --condition "update_time >= date('2024-01-13') and batch_id='20230530_195319' and sensor_count >= 7" --save_dir /clever/pvc-volumes/pvc-cephfs-finfs-100t/zhuhuiping/dataset/autopcdet_demo/raw_data

# 合并两轮车和行人
python merge_pedestrian_cyclist.py --data_dir /clever/pvc-volumes/pvc-cephfs-finfs-100t/zhuhuiping/dataset/autopcdet_demo/raw_data

# 划分数据集
python split_dataset.py --split_type seq --ratio 0.8 --data_dir /clever/pvc-volumes/pvc-cephfs-finfs-100t/zhuhuiping/dataset/autopcdet_demo/raw_data --save_dir /clever/pvc-volumes/pvc-cephfs-finfs-100t/zhuhuiping/dataset/autopcdet_demo/

# 数据预处理
cd detection &&
python -m pcdet.datasets.pandar.pandar_dataset --cfg_file tools/cfgs/dataset_configs/autopcdet_demo_dataset.yaml --raw_data_tag raw_data --processed_data_tag pcdet_demo_processed_data --func create_waymo_infos

# 训练模型
cd tools &&
python train.py --cfg_file cfgs/pandar_models/autopcdet_demo.yaml --extra_tag autopcdet_demo --pretrained_model model/waymo_pv_rcnn_pp_d1.pth --epochs 30 --train_output_dir /clever/pvc-volumes/pvc-cephfs-finfs-100t/zhuhuiping/code/AutoPCDet/output/train_output
# > log/train_autopcdet_demo_$(date "+%Y%m%d%H%M%S").log 2>&1

# 评估模型
## waymo eval
python test.py --cfg_file cfgs/pandar_models/autopcdet_demo.yaml --extra_tag autopcdet_demo --ckpt /clever/pvc-volumes/pvc-cephfs-finfs-100t/zhuhuiping/code/AutoPCDet/output/train_output/autopcdet_demo/ckpt/checkpoint_epoch_30.pth --eval_output_dir /clever/pvc-volumes/pvc-cephfs-finfs-100t/zhuhuiping/code/AutoPCDet/output/eval_output --generator_ids OBJECT_TYPE RANGE

## nuscenes eval
cd ../../ &&
python nuscenes_metric.py --pred_file /clever/pvc-volumes/pvc-cephfs-finfs-100t/zhuhuiping/code/AutoPCDet/output/eval_output/autopcdet_demo/result.pkl --gt_file /clever/pvc-volumes/pvc-cephfs-finfs-100t/zhuhuiping/dataset/autopcdet_demo/pcdet_demo_processed_data_infos_val.pkl --eval_output_dir /clever/pvc-volumes/pvc-cephfs-finfs-100t/zhuhuiping/code/AutoPCDet/output/eval_output --extra_tag autopcdet_demo

# 汇总评估结果
# python summarized_results.py --waymo_result output/eval_output/autopcdet_demo/ap_result.json --nuscenes_result output/eval_output/autopcdet_demo/nu_result.json
