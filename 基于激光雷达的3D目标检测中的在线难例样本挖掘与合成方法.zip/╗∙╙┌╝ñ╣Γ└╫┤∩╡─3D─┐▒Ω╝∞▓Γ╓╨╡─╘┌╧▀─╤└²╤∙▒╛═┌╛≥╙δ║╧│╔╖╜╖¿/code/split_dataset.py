
import os
from pathlib import Path
import random
import argparse

try:
    from pcdet.utils.common_utils import create_logger
    logger = create_logger()
except:
    import logging
    logger = logging.getLogger()

# logger = create_logger()

class SplitDataset(object):
    def __init__(self):
        super().__init__()
                
    def gen_all_files(self, data_dir, save_dir):
        # 生成所有frame的绝对路径并保存在文件中
        all_files = list(Path(data_dir).rglob('*.pcd'))
        all_files = [os.path.abspath(file) for file in all_files if '.ipynb' not in str(file)]
        logger.info(f'all files: {len(all_files)}')
        
        sets_dir = os.path.join(save_dir, 'ImageSets')
        if not os.path.exists(sets_dir):
            os.makedirs(sets_dir, exist_ok=True)
        
        logger.info(f'save all files to {os.path.join(sets_dir, "all_files.txt")}')
        with open(os.path.join(sets_dir, 'all_files.txt'), 'w') as fp:
            for file in all_files:
                fp.write(file + '\n')
                
        return all_files
    
    def gen_all_sequences(self, data_dir, save_dir):
        tabel_names = os.listdir(data_dir)
        tabel_names = [tname for tname in tabel_names if '.ipynb' not in tname]
        logger.info(f'tabel names: {tabel_names}')
        
        all_seqs = []
        sub_seqs = {}
        for tname in tabel_names:
            sub_dir = os.path.join(data_dir, tname)
            sequences = os.listdir(sub_dir)
            sequences = [f'{tname}/{seq}' for seq in sequences if '.ipynb' not in seq]
            all_seqs.extend(sequences)
            
            if tname not in sub_seqs:
                sub_seqs[tname] = sequences
            else:
                sub_seqs[tname].extend(sequences)
        
        logger.info(f'all sequences: {len(all_seqs)}')
        
        sets_dir = os.path.join(save_dir, 'ImageSets')
        if not os.path.exists(sets_dir):
            os.makedirs(sets_dir, exist_ok=True)
        
        logger.info(f'save all sequences to: {os.path.join(sets_dir, "all.txt")}')
        with open(os.path.join(sets_dir, 'all.txt'), 'w') as fp:
            for seq in all_seqs:
                fp.write(seq + '\n')
        
        return all_seqs
    
    def split_sequences(self, sequences, save_dir, ratio=0.8):        
        logger.info('split dataset by sequences...')
        seqs_length = len(sequences)
        if seqs_length == 0:
            train_length = 0
            val_length = 0
        else:
            import math
            val_length = math.ceil((1-ratio) * seqs_length)
            train_length = seqs_length - val_length
        
        logger.info(f'all sequences: {seqs_length}\ttrain sequences: {train_length}\tval sequences:{val_length}')
        
        random.shuffle(sequences)
        
        train_seqs = sequences[:train_length]
        val_seqs = sequences[train_length:]
        
        sets_dir = os.path.join(save_dir, 'ImageSets')
        if not os.path.exists(sets_dir):
            os.makedirs(sets_dir, exist_ok=True)
        
        logger.info(f'save train sequences and val sequences to: {sets_dir}')
        with open(os.path.join(sets_dir, 'train.txt'), 'w') as f1:
            for seq in train_seqs:
                f1.write(seq + '\n')
        
        with open(os.path.join(sets_dir, 'val.txt'), 'w') as f2:
            for seq in val_seqs:
                f2.write(seq + '\n')
        
        return train_seqs, val_seqs
    
    def split_files(self, all_files, save_dir, ratio=0.8):
        logger.info('split dataset by files')
        files_length = len(all_files)
        train_length = int(ratio * files_length)
        val_length = files_length - train_length
        logger.info(f'all files: {files_length}\ttrain files: {train_length}\tval files: {val_length}')
        
        random.shuffle(all_files)
        
        train_files = all_files[:train_length]
        val_files = all_files[train_length:]
        
        sets_dir = os.path.join(save_dir, 'ImageSets')
        if not os.path.exists(sets_dir):
            os.makedirs(sets_dir, exist_ok=True)
    
        logger.info(f'save train files and val files to: {sets_dir}')
        with open(os.path.join(sets_dir, 'train_files.txt'), 'w') as f1:
            for file in train_files:
                f1.write(file + '\n')
                
        with open(os.path.join(sets_dir, 'val_files.txt'), 'w') as f2:
            for file in val_files:
                f2.write(file + '\n')
                
        return train_files, val_files
    
    def split_from_file(self, file_path):
        pass
    
    def split_from_stream(self, all_files):
        pass
    
if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='arg parser')
    parser.add_argument('--split_type', type=str, default='sequences', help='split by sequences or files')
    parser.add_argument('--ratio', type=float, default=0.8, help='split ratio')
    parser.add_argument('--data_dir', type=str, default=None, help='data dir of raw data')
    parser.add_argument('--save_dir', type=str, default=None, help='save directory')
    
    args = parser.parse_args()
    
    logger.info('**********************Start Split Dataset**********************')
    logger.info(f'Split Type: {args.split_type}')
    logger.info(f'Split Ratio: {args.ratio}')
    logger.info(f'Data Dir: {args.data_dir}')
    logger.info(f'Save Dir: {args.save_dir}')
    
    split_op = SplitDataset()
    
    if args.split_type in ['sequences', 'sequence', 'seqs', 'seq']:
        all_seqs = split_op.gen_all_sequences(args.data_dir, args.save_dir)
        split_op.split_sequences(all_seqs, args.save_dir, ratio=args.ratio)
    
    elif args.split_type in ['files', 'file']:
        all_files = split_op.gen_all_files(args.data_dir, args.save_dir)
        split_op.split_files(all_files, args.save_dir, ratio=args.ratio)
    
    else:
        logger.info(f'wrong split type: {args.split_type}')