import os
import json
import shutil
import pandas as pd
from tqdm import tqdm
from pcdet.utils.common_utils import create_logger
from query_client import QueryClient
import argparse
from pathlib import Path

logger = create_logger()

cam_sensors = ['CAM_BACK', 'CAM_BACK_LEFT', 'CAM_BACK_RIGHT', 'CAM_FRONT_120', 'CAM_FRONT_LEFT', 'CAM_FRONT_RIGHT', 'CAM_FISHEYE_FRONT', 'CAM_FISHEYE_LEFT', 'CAM_FISHEYE_RIGHT', 'CAM_FISHEYE_BACK']

fields = 'fileid, raw_json, batch_id, frame_id, data_volume, pcd_path'

class DownloadFileFromMetaBase(object):
    def __init__(self,):
        super().__init__()
        
        self.qc = QueryClient()
        
    def get(self, fields, tabel_name, condition=None, save=False):
        if condition is None:
            query = f"select {fields} from {tabel_name}"
        else:
            query = f"select {fields} from {tabel_name} where {condition}"
        
        logger.info(f'Pulling {tabel_name} data...')
        res = self.qc.fetch_by_sql(query)
        df = pd.DataFrame(res)
        if save:
            df.to_csv(f'data/{tabel_name}_{condition}.csv')
            
        return df
        
    def process_df(self, df, infos, save_dir, start_cursor=0, end_cursor=-1, data_path_prefix='/clever/oss-volumes/pvc-oss-'):
        if start_cursor >= end_cursor:
            return
        
        # 统计重复和不存在的文件,功能待开发
        base_dir = os.path.dirname(save_dir)
#         dups = open(os.path.join(base_dir, 'duplicates.txt'), 'w')
#         abscents = open(os.path.join(base_dir, 'abscents.txt'), 'w')
#         all_files = open(os.path.join(base_dir, 'all_files.txt'), 'w')
        
        for sid in tqdm(range(start_cursor, end_cursor)):
            fileid = df.loc[sid, 'fileid']

            raw_json = df.loc[sid,'raw_json']
            raw_json = json.loads(raw_json)
            data_volume = df.loc[sid, 'data_volume']
            pcd_path = df.loc[sid, 'pcd_path']

            batch_id = df.loc[sid, 'batch_id']
            if batch_id not in infos:
                infos[batch_id] = {}
                        
            frame_id = df.loc[sid, 'frame_id']
            if frame_id in infos[batch_id]:
#                 dups.write(batch_id + '\t' + frame_id + '\n')
                continue
            else:
                infos[batch_id][frame_id] = {}
                        
            # 保存到指定目录
            dst_dir = os.path.join(save_dir, batch_id)
            if not os.path.exists(dst_dir):
                os.makedirs(dst_dir, exist_ok=True)

            sensors = raw_json['meta']['sensor']

            if sensors[-1]['sensor_id'].upper() == 'PANDAR128':
                pcd_name = sensors[-1]['sensor_data']
                data_path = os.path.join(data_volume, pcd_path)
                if not os.path.exists(data_path):
                    data_path =  data_path + sensors[-1]['data_path']
                    if not os.path.exists(data_path_prefix + data_path):
#                         abscents.write(batch_id + '\t' + frame_id + '\n')
                        continue

                # 保存pcd
                dst_lidar_path = os.path.join(dst_dir, pcd_name)
                shutil.copy(data_path, dst_lidar_path)

                # 保存json
                dst_json_path = os.path.join(dst_dir, fileid.replace('.pcd', '.json'))
                with open(dst_json_path, 'w') as fp:
                    json.dump(raw_json, fp)
                        
#                 all_files.write(batch_id + '\t' + frame_id + '\n')
                        
            else:
                print(f'error: {batch_id}/{frame_id}')
                continue
            
            # 拼接相机内外参和畸变系数
            for sensor in sensors:
                sensor_id = sensor['sensor_id'].upper()
                file_name = sensor['sensor_data']

                # todo: 拼接传感器内外参
                if sensor_id not in infos[batch_id][frame_id]:
                    infos[batch_id][frame_id][sensor_id] = {}
                if sensor_id in cam_sensors:
                    height, width = sensor['height'], sensor['width']
                    infos[batch_id][frame_id][sensor_id]['img_size'] = (height, width)

                infos[batch_id][frame_id][sensor_id]['sensor_param'] = sensor['sensor_param']
                        
#         dups.close()
#         abscents.close()
#         all_files.close()
                
    def download_from_file(self, df_path, infos, save_dir):
        df = pd.read_csv(df_path)
        self.process_df(df, infos=infos, save_dir=save_dir, end_cursor=len(df))
    
    def download_from_stream(self, df, infos, save_dir):
        save_dir = os.path.abspath(save_dir)
        if not os.path.exists(save_dir):
            logger.info(f'make save dir: {save_dir}')
            os.makedirs(save_dir, exist_ok=True)
        self.process_df(df, infos=infos, save_dir=save_dir, end_cursor=len(df))
    
if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='arg parser')
    parser.add_argument('--tabel_names', nargs='+', type=str, default='labelresult_image_bevod', help='tabel name in meta base')
    parser.add_argument('--condition', type=str, default=None, help='query conditions')
    parser.add_argument('--save_dir', type=str, default=None, help='save directory')
    
    args = parser.parse_args()
    
    logger.info('**********************Start Download Files**********************')
    
    download_op = DownloadFileFromMetaBase()
    for tabel_name in tqdm(args.tabel_names):
        df = download_op.get(fields=fields, tabel_name=tabel_name, condition=args.condition)
        download_op.download_from_stream(df, {}, save_dir=Path(args.save_dir)/tabel_name)
        
    logger.info('**********************End Download**********************')
   