#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Dec  7 15:28:18 2022

@author: sczone
"""

import numpy as np
import os

IOU_THRES = 0.2

name2cls = {'Vehicle': 0, 'Pedestrian': 1, 'Cyclist': 2}
cls2name = {0: 'Vehicle', 1: 'Pedestrian', 2: 'Cyclist'}

def iou_matching(boxlist_s, boxlist2, box_list_2d_id, box_list_3d_id):
    len_s = len(boxlist_s)
    len_2 = len(boxlist2)
    
    if len_s == 0 or len_2 == 0:
        return [None] * len_s

    cost_matrix = np.zeros((len_s,len_2))

    # todo: fixbug, 该逻辑按3D框的顺序和2D框匹配，未考虑和2D框IoU的大小，应当加入取IoU最大的作为最终匹配结果这样一个逻辑；亦或考虑加入中心点匹配
    vis = [0] * len_2
    match = []
    for i in range(len_s):        
        for j in range(len_2):
            if vis[j] == 0:
                cost_matrix[i][j] = compute_iou(boxlist_s[i],boxlist2[j])

        if cost_matrix[i].max() < IOU_THRES:
            #print(cost_matrix[i])
            match.append(None)
        else:
            index = np.argmax(cost_matrix[i])
            match.append(index)
            vis[index] = 1

    return match

def iou_matching_greedy(boxlist_s, boxlist2, box_list_2d_id, box_list_3d_id):
    len_s = len(boxlist_s)
    len_2 = len(boxlist2)

    if len_s == 0 or len_2 == 0:
        return [None] * len_s

    cost_matrix = np.zeros((len_s, len_2))

    # todo: fixbug, 该逻辑按3D框的顺序和2D框匹配，未考虑和2D框IoU的大小，应当加入取IoU最大的作为最终匹配结果这样一个逻辑；亦或考虑加入中心点匹配
    vis = [(0, -1)] * len_2  # (IoU, box_3d_index)
    match = [None for _ in range(len_s)]  # 匹配结果placeholder
    for i in range(len_s):
        for j in range(len_2):
            # if vis[j] == 0:
            cost_matrix[i][j] = compute_iou(boxlist_s[i], boxlist2[j])

        if cost_matrix[i].max() >= IOU_THRES:
            # print(cost_matrix[i])
            index = np.argmax(cost_matrix[i])
            if vis[index][0] < cost_matrix[i].max():  # 如果vis在index位置已经匹配，但IoU小于现在的IoU，则执行更新
                if vis[index][1] != -1:  # 如果vis在index位置已经匹配上，则将该位置匹配的结果先置为None
                    match[vis[index][1]] = None
                match[i] = index # 更新match的结果
                vis[index] = (cost_matrix[i].max(), i) # 更新Visitd的值
                # try:
                #     loc = match.index(index)
                #     match[loc] = None  # 找到原先和index匹配的位置，置为None
                # except:
                #     print(f'update match: {i}')
                # finally:
                #     match[i] = index  # match 修改
                #     vis[index] = (cost_matrix[i].max(), i)

    return match

def iou_matching_class_specific(boxlist_s, boxlist2, box_list_2d_id, box_list_3d_id, box_list_2d_name, box_list_3d_name):
    len_s = len(boxlist_s)
    len_2 = len(boxlist2)

    if len_s == 0 or len_2 == 0:
        return [None] * len_s

    cost_matrix = np.zeros((len_s, len_2))

    # todo: fixbug, 该逻辑按3D框的顺序和2D框匹配，未考虑和2D框IoU的大小，应当加入取IoU最大的作为最终匹配结果这样一个逻辑；亦或考虑加入中心点匹配
    vis = [(0, -1)] * len_2  # (IoU, box_3d_index)
    match = [None for _ in range(len_s)]  # 匹配结果placeholder
    for category in ['Vehicle', 'Pedestrian', 'Cyclist']:
        for i in range(len_s):
            if box_list_3d_name[i] != category:
                continue

            for j in range(len_2):
                if box_list_2d_name[j] != name2cls[category]:
                    continue

                # if vis[j] == 0:
                cost_matrix[i][j] = compute_iou(boxlist_s[i], boxlist2[j])

            if cost_matrix[i].max() >= IOU_THRES:
                # print(cost_matrix[i])
                index = np.argmax(cost_matrix[i])
                if vis[index][0] < cost_matrix[i].max():  # 如果vis在index位置已经匹配，但IoU小于现在的IoU，则执行更新
                    if vis[index][1] != -1:  # 如果vis在index位置已经匹配上，则将该位置匹配的结果先置为None
                        match[vis[index][1]] = None  # todo: 此处逻辑不完善
                    match[i] = index  # 更新match的结果
                    vis[index] = (cost_matrix[i].max(), i)  # 更新Visitd的值
                    # try:
                    #     loc = match.index(index)
                    #     match[loc] = None  # 找到原先和index匹配的位置，置为None
                    # except:
                    #     print(f'update match: {i}')
                    # finally:
                    #     match[i] = index  # match 修改
                    #     vis[index] = (cost_matrix[i].max(), i)

    return match

def compute_iou(rec1, rec2):
    """
    computing IoU
    :param rec1: (y0, x0, y1, x1), which reflects
            (top, left, bottom, right)
    :param rec2: (y0, x0, y1, x1)
                0 1 2 3
    :return: scala value of IoU
    """
    # computing area of each rectangles
    S_rec1 = (rec1[2] - rec1[0]) * (rec1[3] - rec1[1])
    S_rec2 = (rec2[2] - rec2[0]) * (rec2[3] - rec2[1])
    
    
    S_rec1 = (rec1[2] - rec1[0]) * (rec1[3] - rec1[1])
    S_rec2 = (rec2[2] - rec2[0]) * (rec2[3] - rec2[1])
    # computing the sum_area
    sum_area = S_rec1 + S_rec2

    # find the each edge of intersect rectangle
    left_line = max(rec1[0], rec2[0])
    right_line = min(rec1[2], rec2[2])
    top_line = max(rec1[1], rec2[1])
    bottom_line = min(rec1[3], rec2[3])

    # judge if there is an intersect
    if left_line >= right_line or top_line >= bottom_line:
        return 0
    else:
        intersect = (right_line - left_line) * (bottom_line - top_line)
        return (intersect / (sum_area - intersect))*1.0

def change_2Dbox_coord(x,y,w,h,image_w,image_h):
    
    x = (x * image_w)
    y = (y * image_h )
    w = (w * image_w)
    h = (h * image_h)
    x0 = int(x - w/2)
    x1 = int(x + w/2)
    y0 = int(y - h/2)
    y1 = int(y + h/2)
    return (x0,y0,x1,y1)

def read_image2Dbox(label_file,image_w=1920,image_h=1280):
    f = open(label_file, 'r')
    labels = []
    for line in f.readlines():
        anno ={}            
        line = line.strip().split(' ')
        anno['detection_score_2d'] = float(line[5])
        anno['type'] = int(line[0])
        [x,y,w,h] = [float(x) for x in line[1:5]]
        anno['xy'] = change_2Dbox_coord(x,y,w,h,image_w,image_h)
        line = [float(x) for x in line]
            # print(line)
           
        labels.append(anno)

    return labels

def add_image2Dbox(label_2d_path,image_w=1920,image_h=1280):
    ou_label =[]
    for label2D_file_name in os.listdir(label_2d_path):
        label_file =   os.path.join(label_2d_path, label2D_file_name)
        f = open(label_file, 'r')
        labels = []
        for line in f.readlines():
            anno ={}            
            line = line.strip().split(' ')
            anno['detection_score_2d'] = float(line[5])
            anno['type'] = int(line[0])
            [x,y,w,h] = [float(x) for x in line[1:5]]
            anno['xy'] = change_2Dbox_coord(x,y,w,h,image_w,image_h)
            line = [float(x) for x in line]
            # print(line)
           
            labels.append(anno)
        ou_label.append(labels)
    return ou_label
    
if __name__=='__main__':
    #(y0,x0,y1,x1)
    rect1 = (27, 661,  47,679)
    rect10 = (1, 27, 679, 47)
    # (top, left, bottom, right)
    rect2 = (27, 662, 47, 682)
    rect20 = (6, 27, 0, 47)
    
    image_w = 1920
    image_h = 1280
    
    rect = change_2Dbox_coord(0.610677 ,0.521065, 0.0234375, 0.0337963,image_w,image_h)
    
    iou = compute_iou(rect1, rect2)
    #print(rect)
    box_list1 = [rect10,rect1,rect10,rect2]
    box_list = [rect2,rect20,rect2]
    b = iou_mating(box_list1,box_list)
    print(iou)
    print(b)
    
    
    #label_2d_path = './labels_merge'
    #ou = add_image2Dbox(label_2d_path)