#
import os
from pathlib import Path
from tqdm import tqdm
import shutil

batches = ['20231201-20231130-car2-bevtest-Lidar-20231130_152541_posefixed_3',
           '20231201-20231130-car2-bevtest-Lidar-20231130_171558_posefixed_3',
           '20231201-20231130-car2-bevtest-Lidar-20231130_171657_posefixed_3',
           '20231201-20231130-car2-bevtest-Lidar-20231130_184302_posefixed_3']

cams = ['CAM_BACK', 'CAM_BACK_LEFT', 'CAM_BACK_RIGHT', 'CAM_FRONT_120', 'CAM_FRONT_LEFT', 'CAM_FRONT_RIGHT']

if __name__ == '__main__':
    base_dir = '/opt/dataset/bev-test/'
    _2d5d_dir = os.path.join(base_dir, '2d5d')
    all_json_files = list(Path(_2d5d_dir).rglob('*.json'))
    for jfile in tqdm(all_json_files):
        jdir, jfname = os.path.split(jfile)
        jname = jfname.split('.')[0]
        cur_batch = None
        for batch in batches:
            batch_dir = os.path.join(base_dir, batch)
            for cam in cams:
                cam_dir = os.path.join(batch_dir, 'Images', cam)
                cur_images = os.listdir(cam_dir)
                cur_images = [img.split('.')[0] for img in cur_images]
                if jname in cur_images:
                    cur_batch = batch
                    break
            if cur_batch is not None:
                break

        if cur_batch is not None:
            dst_dir = os.path.join(base_dir, cur_batch, '2d5d')
            if not os.path.exists(dst_dir):
                os.makedirs(dst_dir, exist_ok=True)

            shutil.copy(jfile, os.path.join(dst_dir, jfname))
