#! coding: utf-8
import json
import os.path
import pickle
from pyquaternion import Quaternion
import numpy as np
from collections import defaultdict
from tqdm import tqdm

if __name__ == '__main__':
    val_data_pkl = '/opt/dataset/fusion/20231221_162000/val_data.pkl'
    with open(val_data_pkl, 'rb') as f:
        infos = pickle.load(f)

        calibrations = {}
        for info in tqdm(infos):
            sensors = info['meta']['sensor']
            if len(sensors) < 7:
                print(f"ERROR! {info['meta']['frame_id']}")

            lidar_sensor_path = sensors[-1]['ori_data_path']
            cur_lidar_timestamp = os.path.split(lidar_sensor_path)[1].split('_')[1]
            year, month, day, hour, minu, sec, msec = cur_lidar_timestamp.split('-')
            year = year.zfill(2)
            month = month.zfill(2)
            day = day.zfill(2)
            hour = hour.zfill(2)
            minu = minu.zfill(2)
            sec = sec.zfill(2)
            msec = msec[:3].zfill(3)
            cur_timestamp = year+month+day+hour+minu+sec+msec

            cur_calibration = {}
            for i in range(6):
                cur_cam = sensors[i]
                sensor_id = cur_cam['sensor_id']
                sensor_param = cur_cam['sensor_param']

                # 外参转换
                sensor2ego = np.eye(4)
                sensor2ego_rotation = sensor_param['sensor2ego_rotation']
                sensor2ego_translation = sensor_param['sensor2ego_translation']
                sensor2ego[:3, :3] = Quaternion(sensor2ego_rotation).rotation_matrix
                sensor2ego[:3, 3] = sensor2ego_translation

                # ego2sensor
                ego2sensor = np.linalg.inv(sensor2ego)

                cur_calibration[f'{sensor_id}_to_ego'] = sensor2ego.tolist()
                cur_calibration[f'ego_to_{sensor_id}'] = ego2sensor.tolist()

                if sensor_id not in cur_calibration:
                    cur_calibration[sensor_id] = {}
                cur_calibration[sensor_id]['intrinsics'] = sensor_param['intrinsic']
                cur_calibration[sensor_id]['distort'] = sensor_param['distort']

            # 添加lidar外参
            lidar2ego = np.eye(4)
            lidar2ego_rotation = sensors[-1]['sensor_param']['sensor2ego_rotation']
            lidar2ego_translation = sensors[-1]['sensor_param']['sensor2ego_translation']
            lidar2ego[:3, :3] = Quaternion(lidar2ego_rotation).rotation_matrix
            lidar2ego[:3, 3] = lidar2ego_translation

            # ego2lidar
            # ego2lidar = np.linalg.inv(lidar2ego)

            cur_calibration['Lidar_to_ego'] = lidar2ego.tolist()
            # cur_calibration['ego_to_Lidar'] = ego2lidar

            calibrations[cur_timestamp] = cur_calibration

        with open('/opt/dataset/fusion/20231221_162000/calibration.json', 'w') as fp:
            json.dump(calibrations, fp)

