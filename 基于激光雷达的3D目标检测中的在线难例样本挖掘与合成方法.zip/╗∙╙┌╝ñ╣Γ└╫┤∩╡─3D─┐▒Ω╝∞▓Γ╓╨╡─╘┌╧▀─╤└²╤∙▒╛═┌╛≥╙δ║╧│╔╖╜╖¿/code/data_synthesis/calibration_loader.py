import cv2
import csv
import math
import numpy as np


CAMERAS = dict(
    C0="CAM_FRONT_RIGHT",
    C1="CAM_FRONT_LEFT",
    C2="CAM_BACK",
    C3="CAM_BACK_LEFT",
    C4="CAM_BACK_RIGHT",
    C5="CAM_FRONT_120"
)


def load_calibration(cal_file, camera_id='C5'):
    """
    加载标定文件
    @param cal_file: 标定文件路径
    @param camera_id: 相机编号
    @return:
    """
    if not cal_file.endswith('.csv'):
        return

    with open(cal_file, "r", encoding="utf-8") as f:
        reader = csv.reader(f)
        rows = [row for row in reader]

    calibration = dict()
    for row in rows:
        if row[0] == camera_id:
            for i in range(len(row)):
                if i == 0:
                    calibration[rows[0][i]] = row[i]
                elif i == len(row)-1:
                    calibration[rows[0][i]] = row[i]
                else:
                    calibration[rows[0][i]] = float(row[i])

    return calibration


def rotation_translation(rotation_vector, trans_vector):
    """
    旋转平移矩阵
    @param rotation_vector: dict {"yaw": 0, "pitch":1, "roll":2}
    @param trans_vector: dict {"x": 0, "y":1, "z":2}
    @return:
    """
    c = math.cos(rotation_vector["yaw"])
    s = math.sin(rotation_vector["yaw"])
    Rz = np.array([[c, s, 0], [-s, c, 0], [0, 0, 1]], dtype=float)

    c = math.cos(rotation_vector["pitch"])
    s = math.sin(rotation_vector["pitch"])
    Ry = np.array([[c, 0, -s], [0, 1, 0], [s, 0, c]], dtype=float)

    c = math.cos(rotation_vector["roll"])
    s = math.sin(rotation_vector["roll"])
    Rx = np.array([[1, 0, 0], [0, c, s], [0, -s, c]], dtype=float)

    Rotation = Rx.dot(Ry).dot(Rz)

    trans = np.array([[trans_vector['x'], trans_vector['y'], trans_vector['z']]])
    return Rotation, trans


def get_intrinsics(calibration):
    """
    通过标定文件得到 内参矩阵 3 x 3
    @param calibration:
    @return:
    """
    intrinsics = np.array([calibration['fx'], 0, calibration['cx'], 0, calibration['fy'], calibration['cy'], 0, 0, 1])
    intrinsics = np.reshape(intrinsics, (3, 3))

    distort = np.array([calibration['k1'], calibration['k2'], calibration['k3'], calibration['p1'],
                  calibration['p2']])
    return intrinsics, distort


def get_extrinsics(calibration):
    """
    将坐标点由世界坐标系转到相机坐标
    @param calibration: 标定文件，csv 包含相机外参，内参
    @return:
    """
    rotation_vector = {}
    trans_vector = {}
    rotation_vector['yaw'] = calibration['yaw']
    rotation_vector['pitch'] = calibration['pitch']
    rotation_vector['roll'] = calibration['roll']
    trans_vector['x'] = - calibration['camPosX']
    trans_vector['y'] = - calibration['camPosY']
    trans_vector['z'] = - calibration['camPosZ']

    # 先平移后旋转， 旋转过程，先绕z轴转，y轴-> x轴
    # 平移变量除了原始的x值变换，还需要由后轴到前轴的变话，wheelbase=2.8
    rotation, trans = rotation_translation(rotation_vector, trans_vector)

    # 车体坐标系xyz方向为：x-> left， y->front z->top， 转到相机坐标系 x->right, y->down, z->front
    # cr为此变换矩阵
    # cr = np.array([[-1, 0, 0], [0, 0, -1], [0, 1, 0]])
    cr = np.array([[0, -1, 0], [0, 0, -1], [1, 0, 0]])
    rotation = cr.dot(rotation)
    trans = rotation.dot(trans.T)
    return rotation, trans

def get_lidar_2_ego():
    lidar_2_ego = np.array([[1.06805951e-03,-9.99857909e-01,-1.68729842e-02,1.07098034e+00],
                        [9.99810288e-01,7.39604419e-04,1.94593057e-02,-4.65892236e-02],
                        [-1.94438655e-02,-1.68905455e-02,9.99667673e-01,1.95128934e+00],
                        [0.00000000e+00,0.00000000e+00,0.00000000e+00,1.00000000e+00]])
    return lidar_2_ego


def get_lidar_2_cam120():
    lidar_2_cam120 = np.array([[-0.999695, 0.0244242, 0.00353044, 0.0716466],
                               [-0.00402629, -0.0202752, -0.999786, -0.627634],
                               [-0.0243473, -0.999497, 0.0203673, -0.945709],
                               [0, 0, 0, 1]
        
        ])
    return lidar_2_cam120

if __name__ == "__main__":
     calibration_path = "datasets/calibration.csv"
     calibration = load_calibration(calibration_path, "C5")
     img = cv2.imread('es33/Images/Images/CAM_FRONT_120/n000001_2022-11-18-10-49-53-616_CAM_FRONT_120.jpeg')
     #img = cv2.imread('/newpart/es33/3D/CAM_FRONT_120/n000001_2022-11-18-10-40-01-508_CAM_FRONT_120.jpeg')
     intrinsics, distort = get_intrinsics(calibration)
     print(intrinsics)
     print(distort)
     img_distort = cv2.undistort(img, intrinsics, distort)
     img_diff = cv2.absdiff(img, img_distort)
     #cv2.imshow("img", img_distort)
     #cv2.waitKey(0)
     #cv2.destroyAllWindows()
     cv2.imwrite('a.jpeg',img_distort)