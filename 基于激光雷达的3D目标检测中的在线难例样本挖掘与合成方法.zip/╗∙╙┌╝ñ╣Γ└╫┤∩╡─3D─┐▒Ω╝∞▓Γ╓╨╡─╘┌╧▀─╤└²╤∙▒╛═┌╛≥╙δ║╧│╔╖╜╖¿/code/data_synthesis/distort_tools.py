import math
import cv2
import numpy as np
from scipy.interpolate import griddata


def cam_intr_2_lens(img_size, camera_intrinsic, sensor_width, shift_scale=1.0):
    # sensor_height = sensor_width * img_size[0] / img_size[1]
    # sensor_diagonal = math.sqrt(sensor_width**2 + sensor_height**2)
    # fov_diagonal = 2 * math.atan((sensor_diagonal / 2) / (camera_intrinsic[0, 0]/100))
    # focal_length = (sensor_diagonal / 2) / math.tan(fov_diagonal / 2)
    focal_length2 = (sensor_width / max(img_size[0], img_size[1])) * max(camera_intrinsic[0, 0], camera_intrinsic[1, 1])
    shift_x = -(camera_intrinsic[0, 2] / img_size[0] - 0.5) / shift_scale
    shift_y = ((camera_intrinsic[1, 2] - img_size[1] / 2.0) / img_size[0]) / shift_scale
    return focal_length2, shift_x, shift_y


class DistiortTool():
    # h and w means original height and width of image
    def __init__(self):
        pass

    def update_map(self, distort_coeff, distort_K=None, distort_size=None, undistort_K=None, undistort_size=None,
                   use_distort=False):
        self.update_cam_info(distort_coeff, distort_K, distort_size, undistort_K, undistort_size)
        self.update_map_undistort()
        if use_distort:
            self.update_map_distort()

    def update_cam_info(self, distort_coeff, distort_K=None, distort_size=None, undistort_K=None, undistort_size=None):
        if undistort_size is None and undistort_K is None:
            undistort_size = distort_size
            undistort_K = distort_K
        elif undistort_size is None:
            undistort_w = int(undistort_K[0, 2] * 2)
            undistort_h = int(undistort_K[1, 2] * 2)
            undistort_size = (undistort_w, undistort_h)
        elif undistort_K is None:
            undistort_K = np.eye(3)
            undistort_K[0, 0] = distort_K[0, 0]
            undistort_K[1, 1] = distort_K[1, 1]
            undistort_K[0, 2] = undistort_size[0] / 2
            undistort_K[1, 2] = undistort_size[1] / 2
        if distort_size is None and distort_K is None:
            distort_size = undistort_size
            distort_K = undistort_K
        elif distort_size is None:
            distort_w = int(distort_K[0, 2] * 2)
            distort_h = int(distort_K[1, 2] * 2)
            distort_size = (distort_w, distort_h)
        elif distort_K is None:
            distort_K = np.eye(3)
            distort_K[0, 0] = undistort_K[0, 0]
            distort_K[1, 1] = undistort_K[1, 1]
            distort_K[0, 2] = distort_size[0] / 2
            distort_K[1, 2] = distort_size[1] / 2
        self.distort_coeff = distort_coeff
        self.distort_size = distort_size
        self.distort_K = distort_K
        self.undistort_size = undistort_size
        self.undistort_K = undistort_K
        if len(self.undistort_K.shape) == 1:
            self.undistort_K = np.reshape(self.undistort_K, (3, 3))

    def update_map_undistort(self):
        if len(self.distort_coeff) == 5:
            xi = self.distort_coeff[4]
            distort_coeff = self.distort_coeff[:4]
            self.map_undistort, self.map_undistort2 = cv2.omnidir.initUndistortRectifyMap(self.distort_K, distort_coeff,
                                                                                          xi=np.array(xi), R=np.eye(3),
                                                                                          P=self.undistort_K,
                                                                                          size=self.undistort_size,
                                                                                          m1type=cv2.CV_16SC2, flags=1)
        else:
            distort_coeff = self.distort_coeff
            self.map_undistort, self.map_undistort2 = cv2.fisheye.initUndistortRectifyMap(self.distort_K, distort_coeff,
                                                                                          R=np.eye(3),
                                                                                          P=self.undistort_K,
                                                                                          size=self.undistort_size,
                                                                                          m1type=cv2.CV_16SC2)

    def update_map_distort(self):
        if not hasattr(self, 'map_undistort'):
            self.update_map_undistort()
        if self.undistort_size[0] / self.distort_size[0] > 2.0:
            map_undistort = self.map_undistort.copy()
            map_undistort = cv2.resize(map_undistort, (self.distort_size[0] * 2, self.distort_size[1] * 2),
                                       interpolation=cv2.INTER_LINEAR)
        else:
            map_undistort = self.map_undistort.copy()
        map_undistort_size = (map_undistort.shape[1], map_undistort.shape[0])
        m = [i for i in range(map_undistort_size[0])]
        n = [j for j in range(map_undistort_size[1])]
        distort_points_map = np.meshgrid(m, n)
        M, N = np.meshgrid(m, n)
        self.map_distort1 = griddata(map_undistort.reshape((-1, 2)), distort_points_map[0].reshape(-1), (M, N),
                                     method='cubic')
        self.map_distort2 = griddata(map_undistort.reshape((-1, 2)), distort_points_map[1].reshape(-1), (M, N),
                                     method='cubic')
        self.map_distort1 = self.map_distort1.astype(np.float32)[:self.distort_size[1], :self.distort_size[0]]
        self.map_distort2 = self.map_distort2.astype(np.float32)[:self.distort_size[1], :self.distort_size[0]]
        self.map_distort1 = self.map_distort1 * self.undistort_size[0] / map_undistort_size[0]
        self.map_distort2 = self.map_distort2 * self.undistort_size[1] / map_undistort_size[1]
        self.map_distort = np.concatenate((self.map_distort1[:, :, np.newaxis], self.map_distort2[:, :, np.newaxis]),
                                          axis=2)

    def K_scale_and_zoom(self, K, scale, zoom):
        new_K = K.copy()
        # zoom control large and small of objects
        new_K[0, 0] = K[0, 0] * zoom
        new_K[1, 1] = K[1, 1] * zoom
        # scale control the size of img (when scaling, the size of img must also change)
        new_K[0, 2] = K[0, 2] * scale
        new_K[1, 2] = K[1, 2] * scale
        return new_K

    def load_from_dict(self, dict):
        for key in dict:
            setattr(self, key, dict[key])

    def img_distort(self, img):
        if not hasattr(self, 'map_distort'):
            self.update_map_distort()
        new_img = cv2.remap(img, self.map_distort1, self.map_distort2, interpolation=cv2.INTER_LINEAR,
                            borderMode=cv2.BORDER_CONSTANT)
        return new_img

    def img_undistort(self, img):
        if not hasattr(self, 'map_undistort'):
            self.update_map_undistort()
        new_img = cv2.remap(img, self.map_undistort, self.map_undistort2, interpolation=cv2.INTER_LINEAR,
                            borderMode=cv2.BORDER_CONSTANT)
        return new_img

    def add_distort_to_box(self, box):
        old_box_in_normal = np.array(box).astype(int)
        for i in range(4):
            old_box_in_normal[i] = max(0, old_box_in_normal[i])
        if old_box_in_normal[0] == old_box_in_normal[2]:
            old_box_in_normal[2] = old_box_in_normal[2] + 1
        if old_box_in_normal[1] == old_box_in_normal[3]:
            old_box_in_normal[3] = old_box_in_normal[3] + 1
        # old_box = self.map1[old_box_in_normal[1]: old_box_in_normal[3], old_box_in_normal[0]: old_box_in_normal[2], :]
        old_box = self.map_undistort[old_box_in_normal[1]: old_box_in_normal[3], old_box_in_normal[0]: old_box_in_normal[2], :]
        new_box = [old_box[:, :, 0].min(), old_box[:, :, 1].min(), old_box[:, :, 0].max(), old_box[:, :, 1].max()]
        new_box = np.array(new_box)
        # new_width = int(self.h * self.target_size[0] / self.target_size[1])
        # new_width = int(self.distort_size[0] * (self.distort_size[1] / self.undistort_size[1]))
        new_width = int(self.undistort_size[1] * self.distort_size[0] / self.distort_size[1])
        # new_box[[0, 2]] = new_box[[0, 2]] - (self.w - new_width) // 2
        new_box[[0, 2]] = new_box[[0, 2]] - (self.undistort_size[0] - new_width) // 2
        # new_box[[0, 2]] = new_box[[0, 2]] * (self.target_size[0] / new_width)
        new_box[[0, 2]] = new_box[[0, 2]] * (self.distort_size[0] / new_width)
        # new_box[[1, 3]] = new_box[[1, 3]] * (self.target_size[1] / self.h)
        new_box[[1, 3]] = new_box[[1, 3]] * (self.distort_size[1] / self.undistort_size[1])
        # new_box = [self.map1[old_box_in_normal[1], old_box_in_normal[0], 0], self.map1[old_box_in_normal[1], old_box_in_normal[0], 1], self.map1[old_box_in_normal[3], old_box_in_normal[2] ,0], self.map1[old_box_in_normal[3], old_box_in_normal[2], 1]]
        return new_box

    def add_distort_to_point(self, points):
        new_points = []
        for point in points:
            new_point = self.map_undistort[point[1], point[0], :]
            new_points.append(new_point)
        return np.array(new_points)

    def add_distort_to_label(self, label_dict, ori_normal_img_size):
        new_label_dict = label_dict
        full_boxes = label_dict['bbox_targets']
        front_boxes = label_dict['front_targets']
        side_boxes = label_dict['side_targets']
        for i in range(full_boxes.shape[0]):
            old_full_box = full_boxes[i, :4].copy()
            old_full_box[[0, 2]] = old_full_box[[0, 2]] / ori_normal_img_size[1] * self.w
            old_full_box[[1, 3]] = old_full_box[[1, 3]] / ori_normal_img_size[0] * self.h
            old_front_box = front_boxes[i, :4].copy()
            old_front_box[[0, 2]] = old_front_box[[0, 2]] / ori_normal_img_size[1] * self.w
            old_front_box[[1, 3]] = old_front_box[[1, 3]] / ori_normal_img_size[0] * self.h
            old_side_box = side_boxes[i, :4].copy()
            old_side_box[[0, 2]] = old_side_box[[0, 2]] / ori_normal_img_size[1] * self.w
            old_side_box[[1, 3]] = old_side_box[[1, 3]] / ori_normal_img_size[0] * self.h
            new_full_box = self.add_distort_to_box(old_full_box)
            new_front_box = new_full_box.copy()
            new_side_box = new_full_box.copy()
            # if old_front_box[0] > old_full_box[2]:
            #     old_front_box[0] = old_full_box[2]
            # if old_front_box[2] > old_full_box[2]:
            #     old_front_box[2] = old_full_box[2]
            for j in range(4):
                if abs(old_front_box[j] - old_full_box[j]) < 2:
                    new_front_box[j] = new_full_box[j]
                else:
                    if j % 2 == 0:
                        scale = (old_front_box[j] - old_full_box[0]) / (old_full_box[2] - old_full_box[0])
                        new_front_box[j] = new_full_box[0] + scale * (new_full_box[2] - new_full_box[0])
                    else:
                        scale = (old_front_box[j] - old_full_box[1]) / (old_full_box[3] - old_full_box[1])
                        new_front_box[j] = new_full_box[1] + scale * (new_full_box[3] - new_full_box[1])
                if abs(old_side_box[j] - old_full_box[j]) < 2:
                    new_side_box[j] = new_full_box[j]
                else:
                    if j % 2 == 0:
                        scale = (old_side_box[j] - old_full_box[0]) / (old_full_box[2] - old_full_box[0])
                        new_side_box[j] = new_full_box[0] + scale * (new_full_box[2] - new_full_box[0])
                    else:
                        scale = (old_side_box[j] - old_full_box[1]) / (old_full_box[3] - old_full_box[1])
                        new_side_box[j] = new_full_box[1] + scale * (new_full_box[3] - new_full_box[1])
                new_label_dict['bbox_targets'][i, :4] = new_full_box
                new_label_dict['front_targets'][i, :4] = new_front_box
                new_label_dict['side_targets'][i, :4] = new_side_box
        return new_label_dict

