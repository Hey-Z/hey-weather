import math
import os
import time

import pandas
import yaml
from pyproj import Proj
import pandas as pd
import numpy as np
from datetime import datetime


def rotx(t):
    """Rotation about the x-axis."""
    c = np.cos(t)
    s = np.sin(t)
    return np.array([[1,  0,  0],
                     [0,  c, -s],
                     [0,  s,  c]])


def roty(t):
    """Rotation about the y-axis."""
    c = np.cos(t)
    s = np.sin(t)
    return np.array([[c,  0,  s],
                     [0,  1,  0],
                     [-s, 0,  c]])


def rotz(t):
    """Rotation about the z-axis."""
    c = np.cos(t)
    s = np.sin(t)
    return np.array([[c, -s,  0],
                     [s,  c,  0],
                     [0,  0,  1]])


def lonlat2xy(lon, lat):
    """
    return x,y
    """
    # print((lon, lat))
    # p = Proj("EPSG:4528", preserve_units=False)  # use kwargs
    # x , y = p(float(lon), float(lat))

    er = 6378137.  # earth radius (approx.) in meters
    scale = np.cos(float(lat) * np.pi / 180.)
    # Use a Mercator projection to get the translation vector
    tx = scale * float(lon) * np.pi * er / 180.
    ty = scale * er * \
        np.log(np.tan((90. + float(lat)) * np.pi / 360.))
    return tx, ty
    # return x,y


def calsa(a: tuple, b: tuple):
    return math.sqrt((a[1]-b[1])**2+(a[0]-b[0])**2)


def rotation_translation(rotation_vector, trans_vector, devtype):
    """
    旋转平移矩阵
    @param rotation_vector: dict {"yaw": 0, "pitch":1, "roll":2}
    @param trans_vector: dict {"x": 0, "y":1, "z":2}
    @return:
    """
    # Rx = rotx(float(rotation_vector['roll']) * np.pi / 180)
    # Ry = roty(float(rotation_vector['pitch']) * np.pi / 180)
    # Rz = rotz((float(rotation_vector['yaw']) )  * np.pi / 180   )
    # Rotation = Rz.dot(Ry.dot(Rx))

    # huace euler angles
    Rx = rotx(float(rotation_vector['pitch']) * np.pi / 180)
    Ry = roty(float(rotation_vector['roll']) * np.pi / 180)
    # Rz = rotz((float(rotation_vector['yaw'])) * np.pi / 180)

    # R = Ry.dot(Rx.dot(Rz))
    # change to ZONE body coor
    # at128 0-float pandar128 90-float
    if devtype == "Pandar128":
        Rz = rotz((-float(rotation_vector['yaw'])) * np.pi / 180)
        # R = Ry.dot(Rx.dot(Rz))
        # cr = np.array([[0, -1, 0],
        #                [1, 0, 0],
        #                [0, 0, 1]])
        # Rotation = cr.dot(R)
        # R = Ry.dot(Rx.dot(Rz))

        # Rotation = R
        R = Ry.dot(Rx.dot(Rz))
        #imu转ego
        cr = np.array([[0, -1, 0],
                    [1, 0, 0],
                    [0, 0, 1]])
        Rotation = cr.dot(R)
    elif devtype == "AT128":
        Rz = rotz((-float(rotation_vector['yaw'])) * np.pi / 180)
        R = Ry.dot(Rx.dot(Rz))
        # cr = np.array([[0, -1, 0],
        #                [1, 0, 0],
        #                [0, 0, 1]])
         # imu转ego
        cr = np.array([[1, 0, 0],
                    [0, 1, 0],
                    [0, 0, 1]])
        Rotation = cr.dot(R) 

    trans = np.array(
        [[trans_vector['x'], trans_vector['y'], trans_vector['z']]])
    RT = np.vstack((np.hstack((Rotation, trans.T)), np.array([[0, 0, 0, 1]])))
    return Rotation, trans, RT


def getRT(data, devtype):
    try:
        x, y = lonlat2xy((data["INS_PosLon"]), float(data["INS_PosLat"]))  # old data
        # x, y = float(data["INS_PosLon"]), float(data["INS_PosLat"])          # new data
        z = float(data["INS_PosAlt"])
        # yaw = float(data["INS_Heading"])
        if float(data["INS_Yaw"]) < 0:
            yaw = float(data["INS_Yaw"])+360
        else:
            yaw = float(data["INS_Yaw"])
        roll = float(data["INS_Roll"])
        pitch = float(data["INS_Pitch"])
        # TODO pandar
        fix_ang = 0 if devtype == "AT128" else 90
        Rotation, trans, RT = rotation_translation(
            {"yaw": yaw, "pitch": pitch, "roll": roll}, {"x": x, "y": y, "z": z}, devtype)
        return (True, RT)
    except:
        return (False, None)


def getDefaultPos() -> list:
    return [1.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 0.0, 1.0]


def mergeCsv(csvFilePath: str) -> pd.DataFrame:
    '''
    根据目录合并csv到一个Dataframe中
    csvFilePath: csv文件所在目录
    '''
    res = None
    for root, dirs, files in os.walk(csvFilePath):
        for file in files:
            if file.endswith(".csv"):
                data = pd.read_csv(os.path.join(csvFilePath, file))
                if res is None:
                    res = data
                else:
                    res = pd.concat([res, data])
    return res


def getEgo2WorldNearest(data: pd.DataFrame, pcdName: str, devtype: str) -> tuple:
    '''
    根据pcd名称找到DataFrame中对应的入参从而得到世界坐标系旋转平移矩阵
    取最近一帧
    自车到世界坐标系转化


    '''
    eventDataTimeOrg = pcdName.split("_")[1]
    eventDataTimeOrg = eventDataTimeOrg.split("-")
    eventDataTimeOrg[-1] = eventDataTimeOrg[-1][:3]
    eventDataTimeOrg = "-".join(eventDataTimeOrg)
    eventDataTime = time.strptime(eventDataTimeOrg, "%Y-%m-%d-%H-%M-%S-%f")
    eventDataTimeRes = time.strftime("%Y/%m/", eventDataTime) + str(eventDataTime.tm_mday) + time.strftime(" %H:%M:%S.",
                                                                                                           eventDataTime) + \
        eventDataTimeOrg.split("-")[-1][:3]

    try:
        datetime_obj = datetime.strptime(
            eventDataTimeRes, "%Y/%m/%d %H:%M:%S.%f")
        ret_stamp = int(time.mktime(datetime_obj.timetuple())
                        * 1000.0 + datetime_obj.microsecond / 1000.0)

        # 缩小处理范围加快处理速度取前后4scan数据

        datatmp = data[data["timestamp"] >= time.strftime(
            "%Y/%-m/%-d %-H:%M:%S", time.localtime(ret_stamp / 1000 - 2))]
        datatmp = datatmp[datatmp["timestamp"] <= time.strftime(
            "%Y/%-m/%-d %-H:%M:%S", time.localtime(ret_stamp / 1000 + 2))]

        datatmp["timestamp_diff"] = datatmp[["timestamp"]].apply(lambda x: int(
            time.mktime(datetime.strptime(x["timestamp"], "%Y/%m/%d %H:%M:%S.%f").timetuple()) * 1000.0 + datetime.strptime(
                x["timestamp"], "%Y/%m/%d %H:%M:%S.%f").microsecond / 1000.0) - ret_stamp, axis=1)
        datatmp["timestamp_diff_abs"] = datatmp[["timestamp"]].apply(lambda x: math.fabs(int(time.mktime(
            datetime.strptime(x["timestamp"], "%Y/%m/%d %H:%M:%S.%f").timetuple()) * 1000.0 + datetime.strptime(
            x["timestamp"], "%Y/%m/%d %H:%M:%S.%f").microsecond / 1000.0) - ret_stamp), axis=1)
        nearest = datatmp[datatmp["timestamp_diff_abs"] == datatmp.min(
        ).to_dict().get("timestamp_diff_abs")].iloc[-1].to_dict()
        resRT = getRT(nearest, devtype)
        # print(nearest)
        return (resRT, nearest)
    except Exception as e:
        import traceback
        print(e)
        just_the_string = traceback.format_exc()
        print(just_the_string)
        return (False, None)


def getEgo2WorldNearestBytimeobj(data: pd.DataFrame, timeobj, devtype):
    '''
    根据时间戳找到DataFrame中对应的入参从而得到世界坐标系旋转平移矩阵
    取最近一帧
    自车到世界坐标系转化


    '''

    try:
        ret_stamp = int(time.mktime(timeobj.timetuple())
                        * 1000.0 + timeobj.microsecond / 1000.0)

        # 缩小处理范围加快处理速度取前后4scan数据

        datatmp = data[data["timestamp"] >= time.strftime(
            "%Y/%-m/%-d %-H:%M:%S", time.localtime(ret_stamp / 1000 - 2))]
        datatmp = datatmp[datatmp["timestamp"] <= time.strftime(
            "%Y/%-m/%-d %-H:%M:%S", time.localtime(ret_stamp / 1000 + 2))]

        datatmp["timestamp_diff"] = datatmp[["timestamp"]].apply(lambda x: int(
            time.mktime(datetime.strptime(x["timestamp"], "%Y/%m/%d %H:%M:%S.%f").timetuple()) * 1000.0 + datetime.strptime(
                x["timestamp"], "%Y/%m/%d %H:%M:%S.%f").microsecond / 1000.0) - ret_stamp, axis=1)
        datatmp["timestamp_diff_abs"] = datatmp[["timestamp"]].apply(lambda x: math.fabs(int(time.mktime(
            datetime.strptime(x["timestamp"], "%Y/%m/%d %H:%M:%S.%f").timetuple()) * 1000.0 + datetime.strptime(
            x["timestamp"], "%Y/%m/%d %H:%M:%S.%f").microsecond / 1000.0) - ret_stamp), axis=1)
        nearest = datatmp[datatmp["timestamp_diff_abs"] == datatmp.min(
        ).to_dict().get("timestamp_diff_abs")].iloc[-1].to_dict()
        resRT = getRT(nearest, devtype)
        # print(nearest)
        return (resRT, nearest)
    except Exception as e:
        import traceback
        print(e)
        just_the_string = traceback.format_exc()
        print(just_the_string)
        return (False, None)


def getPosAvg(nearestPre: dict, nearestNext: dict, tm: dict) -> dict:
    """
    @param nearestPre 前向最近帧
    @param nearestNext 后向最近帧
    @param tm 当前时间戳ms

    利用前向最近帧和后向最近帧计算当前帧真值
    """

    a = float(nearestPre["timestamp_diff_abs"])/(
        float(nearestPre["timestamp_diff_abs"])+float(nearestNext["timestamp_diff_abs"]))
    b = float(nearestNext["timestamp_diff_abs"])/(
        float(nearestPre["timestamp_diff_abs"])+float(nearestNext["timestamp_diff_abs"]))
    current = {
    }
    current["identify_id"] = nearestPre["identify_id"]
    current["timestamp"] = tm
    current["INS_PosLon"] = a * \
        float(nearestPre["INS_PosLon"])+b*float(nearestNext["INS_PosLon"])
    current["INS_PosLat"] = a * \
        float(nearestPre["INS_PosLat"])+b*float(nearestNext["INS_PosLat"])
    current["INS_PosAlt"] = a * \
        float(nearestPre["INS_PosAlt"])+b*float(nearestNext["INS_PosAlt"])
    current["INS_Heading"] = a * \
        float(nearestPre["INS_Heading"])+b*float(nearestNext["INS_Heading"])
    current["INS_Roll"] = a * \
        float(nearestPre["INS_Roll"])+b*float(nearestNext["INS_Roll"])
    current["INS_Pitch"] = a * \
        float(nearestPre["INS_Pitch"])+b*float(nearestNext["INS_Pitch"])
    current["timestamp_diff"] = 0
    current["timestamp_diff_abs"] = .0
    return current


def getEgo2WorldNearestPreNext(data: pd.DataFrame, pcdName: str) -> tuple:
    '''
    根据pcd名称找到DataFrame中对应的入参从而得到世界坐标系旋转平移矩阵
    取前向最近帧和后向最近帧取均值
    自车到世界坐标系转化
    '''
    eventDataTimeOrg = pcdName.split("_")[1]
    eventDataTimeOrg = eventDataTimeOrg.split("-")
    eventDataTimeOrg[-1] = eventDataTimeOrg[-1][:3]
    eventDataTimeOrg = "-".join(eventDataTimeOrg)
    eventDataTime = time.strptime(eventDataTimeOrg, "%Y-%m-%d-%H-%M-%S-%f")
    eventDataTimeRes = time.strftime("%Y/%m/", eventDataTime) + str(eventDataTime.tm_mday) + time.strftime(" %H:%M:%S.",
                                                                                                           eventDataTime) + \
        eventDataTimeOrg.split("-")[-1][:3]

    try:
        datetime_obj = datetime.strptime(
            eventDataTimeRes, "%Y/%m/%d %H:%M:%S.%f")
        ret_stamp = int(time.mktime(datetime_obj.timetuple())
                        * 1000.0 + datetime_obj.microsecond / 1000.0)

        # 缩小处理范围加快处理速度取前后4scan数据
        datatmp = data[data["timestamp"] >= time.strftime(
            "%Y/%m/%d %H:%M:%S", time.localtime(ret_stamp / 1000 - 2))]
        datatmp = datatmp[datatmp["timestamp"] <= time.strftime(
            "%Y/%m/%d %H:%M:%S", time.localtime(ret_stamp / 1000 + 2))]

        datatmp["timestamp_diff"] = datatmp[["timestamp"]].apply(lambda x: int(
            time.mktime(datetime.strptime(x["timestamp"], "%Y/%m/%d %H:%M:%S.%f").timetuple()) * 1000.0 + datetime.strptime(
                x["timestamp"], "%Y/%m/%d %H:%M:%S.%f").microsecond / 1000.0) - ret_stamp, axis=1)
        datatmp["timestamp_diff_abs"] = datatmp[["timestamp"]].apply(lambda x: math.fabs(int(time.mktime(
            datetime.strptime(x["timestamp"], "%Y/%m/%d %H:%M:%S.%f").timetuple()) * 1000.0 + datetime.strptime(
            x["timestamp"], "%Y/%m/%d %H:%M:%S.%f").microsecond / 1000.0) - ret_stamp), axis=1)
        # nearest = datatmp[datatmp["timestamp_diff_abs"] == datatmp.min().to_dict().get("timestamp_diff_abs")].iloc[-1].to_dict()

        nearestPre = datatmp[datatmp["timestamp"]
                             <= eventDataTimeRes].iloc[-1].to_dict()
        nearestNext = datatmp[datatmp["timestamp"]
                              >= eventDataTimeRes].iloc[0].to_dict()

        current = getPosAvg(nearestPre, nearestNext, eventDataTimeRes)

        resRT = getRT(current)
        # print(current)
        return (resRT, current)
    except:
        return (False, None)


def _get_yaml(filename: str = "cam_front") -> dict:
    """
    解析yaml
    :return: s  字典
    """
    path = os.path.join(os.path.dirname(__file__) +
                        './config/'+filename+'.yaml')
    f = open(path, encoding='utf-8')
    s = yaml.load(f, Loader=yaml.FullLoader)
    f.close()
    return s.decode() if isinstance(s, bytes) else s


def get_for_send(data, pcdname, lidar2egodata, devtype):
    # lidar2egodata
    # r
    # [0.00106805951, -0.999857909, -0.0168729842, 0.999810288, 0.000739604419, 0.0194593057, -0.0194438655, -0.0168905455, 0.999667673]
    # t
    # [1.07098034, -0.0465892236, 1.95128934]
    # data megecv(/sharenfs/20230114-ipd-Lidar/3D_Data_LSJWK4096NS998823_Segments/20230107_085321/CAN_Trace/CAN5/)
    # data megecv(/sharenfs/20230114-ipd-Lidar/3D_Data_LSJWK4096NS998823_Segments/20230107_085321/CAN_Trace/CAN5/)
    # pcdName = "n000002_2023-01-07-08-53-35-859600_AT128.pcd"
    data = data[data["INS_PosLon"] != 'None']
    # "INS_Yaw": "141.36000000",
    #  "vx": 10,
    # "vy": 0.2,
    # "vz": 0,
    # "wpitch": 0.05,
    # "wroll": 0,
    # "wyaw": 0.3
    data = data[
        ["identify_id", "timestamp", "INS_PosLon", "INS_PosLat", "INS_PosAlt", "INS_Heading", "INS_Roll", "INS_Pitch", "INS_Yaw","INS_VelE","INS_VelN","INS_VelU","INS_VehicleGyroX","INS_VehicleGyroY","INS_VehicleGyroZ"]]
    data.sort_values(by='timestamp', ascending=True)
    # if devtype == "AT128":
    #     res = getEgo2WorldNearest(data, pcdname, devtype)
    # else:
    res = getEgo2WorldNearestBytimeobj(data, pcdname, devtype)
    if res[0] is False:
        return None, None, None
    RT = np.vstack(
        (np.hstack((np.array(lidar2egodata['R']).reshape(3, 3), np.array(lidar2egodata['T']).reshape(3, 1))), np.array([[0, 0, 0, 1]])))
    # get ego2world
    ego2world = res[0][1]
    # lidar2world
    lidar2world = np.dot(ego2world, RT)
    # 原始json赋值
    # ["vehicle2odom"]
    vehicle2odom = lidar2world.reshape(16).tolist()
    # ["pose"]["matrix4"]
    pose_matrix4 = vehicle2odom
    # ["ego2world"]
    ego2world = ego2world.reshape(16).tolist()
    # ["nearestCanTraceData"]
    nearestCanTraceData = res[1]

    return vehicle2odom, ego2world, nearestCanTraceData


if __name__ == "__main__":
    data = mergeCsv(
        "/sharenfs/20221216-Lidar/3D_Data_LSJWK4096NS998823/20221216_000000/CAN_Trace/")
    pcdName = "n000001_2022-12-16-15-28-44-280676_Pandar128.pcd"
    data = data[data["INS_PosLon"] != 'None']
    data = data[
        ["identify_id", "timestamp", "INS_PosLon", "INS_PosLat", "INS_PosAlt", "INS_Heading", "INS_Roll", "INS_Pitch", "INS_Yaw"]]
    data.sort_values(by='timestamp', ascending=True)
    res = getEgo2WorldNearest(data, pcdName)

    # get lidar2ego
    pcd_img_urls = _get_yaml(filename="pcd_img_urls")
    R = pcd_img_urls["lidar2ego_R"]
    T = pcd_img_urls["lidar2ego_T"]
    RT = np.vstack(
        (np.hstack((np.array(R).reshape(3, 3), np.array(T).reshape(3, 1))), np.array([[0, 0, 0, 1]])))

    # get ego2world
    ego2world = res[0][1]

    # lidar2world
    lidar2world = np.dot(RT, ego2world)

    # 原始json赋值
    # ["vehicle2odom"]
    vehicle2odom = lidar2world.reshape(16).tolist()

    # ["pose"]["matrix4"]
    pose_matrix4 = vehicle2odom

    # ["ego2world"]
    ego2world = ego2world.reshape(16).tolist()

    # ["nearestCanTraceData"]
    nearestCanTraceData = res[1]

    print("vehicle2odom<=>['pose']['matrix4']:", vehicle2odom)
    print("ego2world:", ego2world)
    print("nearestCanTraceData:", nearestCanTraceData)
    # a= [-0.9965391347655197,0.08300957796470644,0.0043775389102411804,-0.11321146413683891,-0.08298114885438862,-0.9965310820273935,0.006319136659240747,-0.008905559778213501,0.0048869024540245404,0.005934013770938249,0.9999704523959551,0.0]
    # print(np.array(a).reshape(3,4))
