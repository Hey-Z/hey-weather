#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Dec  1 17:30:54 2022

@author: sczone
"""

import os
import numpy as np
import json
import cv2

def load_intrinsic_from_json(calibration_path, cam_name):
    """
    
    """
    f = open(calibration_path)
    load_data = json.load(f)
    intrinsics = np.array(load_data[cam_name]['intrinsic'])
    distort = np.array(load_data[cam_name]['distort'])

    return intrinsics, distort


CAMERAS_TO_ID = dict(
    CAM_FRONT_RIGHT="C0",
    CAM_FRONT_LEFT="C1",
    CAM_BACK="C2",
    CAM_BACK_LEFT="C3",
    CAM_BACK_RIGHT="C4",
    CAM_FRONT_120="C5"
)

#cam_names = ["CAM_FRONT_LEFT", "CAM_FRONT_120", "CAM_FRONT_RIGHT", "CAM_BACK_LEFT", "CAM_BACK", "CAM_BACK_RIGHT"]

cam_names = ["CAM_FRONT_120"]

root_save_path = './raw_data/Images_undistort'
calibration_path = 'datasets/calibration.json'

data_root_path = '/mnt/data/zlidar/20221118_104953'
image_src_path = os.path.join(data_root_path, 'Images')


'''
val_part_list  = open(file_list).readlines()
for f in val_part_list:    
    filename = f.replace('\n','') 
'''
for cam_name in cam_names:

    intrinsics, distort = load_intrinsic_from_json(calibration_path, cam_name)
    print(intrinsics)
    print(distort)

    image_path = os.path.join(image_src_path, cam_name) 
    save_path = os.path.join(root_save_path,cam_name)

    for cam_file_name in os.listdir(image_path):
        image_name = os.path.join(image_path,cam_file_name)
        img = cv2.imread(image_name)

        img_distort = cv2.undistort(img, intrinsics, distort)
        # cv2.imwrite(os.path.join(save_path, cam_file_name), img_distort)
    