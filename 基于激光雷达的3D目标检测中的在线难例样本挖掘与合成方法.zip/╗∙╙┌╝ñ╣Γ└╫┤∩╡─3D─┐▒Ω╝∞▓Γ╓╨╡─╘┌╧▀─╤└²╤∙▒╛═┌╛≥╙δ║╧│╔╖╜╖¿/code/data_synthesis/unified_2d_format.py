import os.path
import pickle
import re
from pathlib import Path

import cv2
from tqdm import tqdm

sensors = ['CAM_BACK', 'CAM_BACK_LEFT', 'CAM_BACK_RIGHT', 'CAM_FRONT_120', 'CAM_FRONT_LEFT', 'CAM_FRONT_RIGHT',
           'CAM_FISHEYE_BACK', 'CAM_FISHEYE_FRONT', 'CAM_FISHEYE_LEFT', 'CAM_FISHEYE_RIGHT', 'Pandar128']

cam_size = {
    "CAM_FRONT_LEFT" : [1920,1280],
    "CAM_FRONT_120" : [3840,2160],
    "CAM_FRONT_RIGHT" : [1920,1280],
    "CAM_BACK_LEFT" : [1920,1280] ,
    "CAM_BACK": [1920,1280],
    "CAM_BACK_RIGHT": [1920,1280],
    "CAM_FISHEYE_BACK": [1920, 1536],
    "CAM_FISHEYE_FRONT": [1920, 1536],
    "CAM_FISHEYE_LEFT": [1920, 1536],
    "CAM_FISHEYE_RIGHT": [1920, 1536]
}
name2cls_wmj_v1 = {'Other': 4, 'Passenger_Car': 1, 'Bus_Small': 0, 'Bus_Big': 0, 'Truck_Light': 2, 'Truck_Heavy': 2, 'Van': 1, 'Tricycle': 3}

cls2name_gk = {
    0: 'Other', 1: 'Passenger_Car', 2: 'Bus_Small', 3: 'Bus_Big', 4: 'Truck_Light', 5: 'Truck_Heavy', 6: 'Van', 7: 'Tricycle'
}

def draw_bbox_on_img(pkl_file, img_file, save_dir):
    base_dir, file_name = os.path.split(pkl_file)
    if 'CAM' in file_name:
        sensor_name = 'CAM' + file_name.split('.')[0].split('CAM')[-1]
    elif 'Pandar128' in file_name:
        sensor_name = 'Pandar128'
    else:
        print('error!')
        sensor_name = 'Unknown'

    with open(pkl_file, 'rb') as fp:
        contents = pickle.load(fp)
        if len(contents) == 0:
            return
    save_path = os.path.join(save_dir, sensor_name)
    if not os.path.exists(save_path):
        os.makedirs(save_path, exist_ok=True)

    img = cv2.imread(img_file)
    for content in contents:
        bbox = content['full_box']
        cv2.rectangle(img, (int(bbox[0]), int(bbox[1])), (int(bbox[2]), int(bbox[3])), color=(0, 255, 0))

    dst_file = os.path.join(save_path, file_name.replace('.pkl', '.jpg'))
    cv2.imwrite(dst_file, img)

def transform_pkl_to_txt(pkl_file, save_dir):
    base_dir, file_name = os.path.split(pkl_file)
    if 'CAM' in file_name:
        sensor_name = 'CAM' + file_name.split('.')[0].split('CAM')[-1]
    elif 'Pandar128' in file_name:
        sensor_name = 'Pandar128'
    else:
        print('error!')
        sensor_name = 'Unknown'

    save_path = os.path.join(save_dir, sensor_name)
    if not os.path.exists(save_path):
        os.makedirs(save_path, exist_ok=True)

    new_contents = []
    dst_file = os.path.join(save_path, file_name.replace('.pkl', '.txt'))
    new_file = open(dst_file, 'w')
    with open(pkl_file, 'rb') as fp:
        contents = pickle.load(fp)
        for content in contents:
            score = 1.0  # 占位

            cls = 0 # '只检测车辆'
            sub_cls = int(content['cls'])
            sub_name = cls2name_gk[sub_cls]
            sub_cls_wmj_v1 = name2cls_wmj_v1[sub_name] # 映射到mj模型v1版本类别

            bbox = content['full_box']
            img_w, img_h = cam_size[sensor_name]
            cx, cy, w, h = (bbox[2] + bbox[0]) / 2, (bbox[3] + bbox[1]) / 2, (bbox[2] - bbox[0]), (bbox[3] - bbox[1])
            norm_cx, norm_cy, norm_w, norm_h = format(cx / img_w, '.6g'), format(cy / img_h, '.6g'), \
                                            format(w / img_w, '.6g'), format(h / img_h, '.6g')  # 框保持中心点宽高的形式，归一化

            front_cls, side_cls = content['front_cls'], content['side_cls']
            front_coeff = 0 if front_cls == 2 else 1  # 确定遮挡系数，类别为2则不计算遮挡率，类别为1（车尾）和0（车头）计算遮挡率
            side_coeff = 0 if side_cls == 2 else 1
            front_occulation, side_occulation = content['front_occulation'], content['side_occulation']  # 三级遮挡率0\1\2
            front_box, side_box = content['front_box'], content['side_box']
            front_area = (front_box[2] - front_box[0]) * (front_box[3] - front_box[1])
            side_area = (side_box[2] - side_box[0]) * (side_box[3] - side_box[1])
            if front_coeff != 0 and side_coeff != 0:
                occulation = format(((front_area * front_occulation) + (side_area * side_occulation)) / (2*(front_area + side_area)), '.6g')  # 根据面积加权车头和车身遮挡率,再归一化
            else:
                occulation = format((front_coeff * front_occulation + side_coeff * side_occulation) / 2, '.6g')

            truncation = format(content['truncation'], '.6g')  # 截断率

            msg = f'{cls} {norm_cx} {norm_cy} {norm_w} {norm_h} {score} {sub_cls_wmj_v1} {occulation} {truncation}'
            new_contents.append(msg)

    # 写入新的txt文件中
    for new_c in new_contents:
        new_file.write(new_c + '\n')


if __name__ == '__main__':
    pkl_dir = '/opt/dataset/post-fusion-fisheye2/ImageResPKL'
    save_dir = '/opt/dataset/post-fusion-fisheye2/ImageRes'
    img_dir = '/opt/dataset/post-fusion-fisheye2/Images'
    all_files = list(Path(pkl_dir).rglob('*.pkl'))
    print(len(all_files))
    all_img_files = list(Path(img_dir).rglob('*.jpeg'))
    all_img_files = [os.path.abspath(file) for file in all_img_files if '.ipynb' not in str(file) and 'FISHEYE' in str(file)]
    print(len(all_img_files))

    all_files = [os.path.abspath(file) for file in all_files if '.ipynb' not in str(file)]
    for pkl_file in tqdm(all_files):
        img_name = os.path.split(pkl_file)[1].replace('.pkl', '.jpeg')
        sensor_name = 'CAM' + img_name.split('.')[0].split('CAM')[-1]
        img_file = os.path.join(img_dir, sensor_name, img_name)
        transform_pkl_to_txt(pkl_file, save_dir)
        # draw_bbox_on_img(pkl_file, img_file, save_dir)
