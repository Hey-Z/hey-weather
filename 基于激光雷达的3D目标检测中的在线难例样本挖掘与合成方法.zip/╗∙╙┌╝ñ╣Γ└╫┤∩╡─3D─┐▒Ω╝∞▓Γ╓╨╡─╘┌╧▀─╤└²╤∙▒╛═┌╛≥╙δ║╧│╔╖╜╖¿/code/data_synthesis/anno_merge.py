# import pickle
import copy

cam_names = ["CAM_FRONT_LEFT", "CAM_FRONT_120", "CAM_FRONT_RIGHT", "CAM_BACK_LEFT", "CAM_BACK", "CAM_BACK_RIGHT"]
class_names = ['Vehicle', 'Pedestrian', 'Cyclist']

def fuse_annos(raw_data, cam_names):

    # f = open(raw_data_path, 'rb')
    # raw_data = pickle.load(f)
    fusion_data = []
    for content in raw_data:
        annos = content['annotations']
        all_ids_match = []
        annos_fusion = []
        label_3d_fusion = dict()
        #label_2d_match = []
        for cam in cam_names:
            infos_cur = content['cams'][cam]
            label_2d = infos_cur['label2D']
            label_3d = infos_cur['label3D']
            match_3d = infos_cur['match3D']
            label_3d_match_cur = []
            label_2d_match_cur = []
            for index, ele in enumerate(match_3d):
                if ele is not None:
                    label_3d_match_cur.append(label_3d[index])
                    label_2d_match_cur.append(label_2d[ele])

            if len(label_2d_match_cur) > 0:
                for ele_3d, ele_2d in zip(label_3d_match_cur,label_2d_match_cur):
                    label_3d_fusion_cur = dict()
                    if ele_3d['id'] not in all_ids_match:
                        all_ids_match.append(ele_3d['id'])
                        #label_3d_fusion_cur['id'] = ele_3d['id']
                        label_3d_fusion_cur['detection_score_2d'] = ele_2d['detection_score_2d']
                        # if '2d_box' not in label_3d_fusion_cur:
                        #     label_3d_fusion_cur['2d_box'] = {}
                        # if cam not in label_3d_fusion_cur['2d_box']:
                        # label_3d_fusion_cur['2d_box'][cam] = ele_2d['xy']
                        label_3d_fusion_cur['2d_type'] = ele_2d['type']
                        label_3d_fusion_cur['2d_subtype'] = ele_2d['sub_type']
                        # todo: 加入遮挡率和截断率
                        if 'front_cls' in ele_2d:
                            label_3d_fusion_cur['front_cls'] = ele_2d['front_cls']
                        if 'side_cls' in ele_2d:
                            label_3d_fusion_cur['side_cls'] = ele_2d['side_cls']
                        if 'occlusion_front' in ele_2d:
                            label_3d_fusion_cur['occlusion_front'] = ele_2d['occlusion_front']
                        if 'occlusion_side' in ele_2d:
                            label_3d_fusion_cur['occlusion_side'] = ele_2d['occlusion_side']
                        if 'truncation' in ele_2d:
                            label_3d_fusion_cur['truncation'] = ele_2d['truncation']

                        label_3d_fusion[ele_3d['id']] = label_3d_fusion_cur

                    # 更新在哪个相机中可见
                    if 'visible_in_cams' not in label_3d_fusion[ele_3d['id']]:
                        label_3d_fusion[ele_3d['id']]['visible_in_cams'] = []
                    label_3d_fusion[ele_3d['id']]['visible_in_cams'].append(cam)
                    if '2d_box' not in label_3d_fusion[ele_3d['id']]:
                        label_3d_fusion[ele_3d['id']]['2d_box'] = {}
                    label_3d_fusion[ele_3d['id']]['2d_box'][cam] = ele_2d['xy']

        for anno in annos:
            if anno['id'] in all_ids_match:
                anno_fus = copy.deepcopy(anno)
                anno_fus.update(label_3d_fusion[anno['id']])
                anno_fus['gt_names'] = class_names[label_3d_fusion[anno['id']]['2d_type']]  # todo：这里有可能会将2d检错的类别赋到3d结果中
                annos_fusion.append(anno_fus)
        
        content['annotations_fusion'] = annos_fusion

        fusion_data.append(content)

    return fusion_data


def fuse_annos_filter(raw_data, cam_names):

    # f = open(raw_data_path, 'rb')
    # raw_data = pickle.load(f)
    fusion_data = []
    for content in raw_data:
        annos = content['annotations']
        all_ids_match = []
        annos_fusion = []
        label_3d_fusion = dict()
        #label_2d_match = []
        for cam in cam_names:
            infos_cur = content['cams'][cam]
            label_2d = infos_cur['label2D']
            label_3d = infos_cur['label3D']
            match_3d = infos_cur['match3D']
            label_3d_match_cur = []
            label_2d_match_cur = []
            for index, ele in enumerate(match_3d):
                if ele is not None:
                    label_3d_match_cur.append(label_3d[index])
                    label_2d_match_cur.append(label_2d[ele])

            if len(label_2d_match_cur) > 0:
                for ele_3d, ele_2d in zip(label_3d_match_cur,label_2d_match_cur):
                    label_3d_fusion_cur = dict()
                    if ele_3d['id'] not in all_ids_match:
                        all_ids_match.append(ele_3d['id'])
                        #label_3d_fusion_cur['id'] = ele_3d['id']
                        label_3d_fusion_cur['detection_score_2d'] = ele_2d['detection_score_2d']
                        label_3d_fusion_cur['2d_type'] = ele_2d['type']
                        label_3d_fusion_cur['2d_subtype'] = ele_2d['sub_type']
                        label_3d_fusion[ele_3d['id']] = label_3d_fusion_cur

        for anno in annos:
            if anno['id'] in all_ids_match:
                anno_fus =  copy.deepcopy(anno)
                anno_fus.update(label_3d_fusion[anno['id']])
                anno_fus['gt_names'] = class_names[label_3d_fusion[anno['id']]['2d_type']]
                annos_fusion.append(anno_fus)
            else:
                if anno['detection_score'] >= 0.95:  # 0.95的阈值是否太高
                    anno_fus = copy.deepcopy(anno)
                    annos_fusion.append(anno_fus)

        content['annotations_fusion'] = annos_fusion

        fusion_data.append(content)

    return fusion_data



            

            
            

            



