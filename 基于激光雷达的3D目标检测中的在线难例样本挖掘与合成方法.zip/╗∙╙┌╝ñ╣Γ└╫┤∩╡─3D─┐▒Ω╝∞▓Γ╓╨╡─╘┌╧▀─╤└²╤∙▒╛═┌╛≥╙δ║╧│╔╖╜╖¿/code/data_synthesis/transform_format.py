import os
import json
import time
import datetime
import numpy as np
import transforms3d
from typing import List, Dict
import pickle


category_map = {"Vehicle": "MotorVehicle",
                "Pedestrian": "Pedestrian",
                "Cyclist": "Two-wheels",}


vehicle_sub_category_map = {
                    0: "Commercial Bus",
                    1: "PassengerCar",
                    2: "Commercial Truck",
                    3: "Tricycle",
                    4: "OtherVehicle",}


def get_roll_pitch_yaw(rotation_matrix):
    roll, pitch, yaw = transforms3d.euler.mat2euler(rotation_matrix)
    return roll, pitch, yaw


def get_quaternion(rotation_matrix):
    return transforms3d.quaternions.mat2quat(np.array(rotation_matrix))


def time2stamp(date):
    date = datetime.datetime.strptime(date, '%Y-%m-%d-%H-%M-%S-%f')
    timestamp = time.mktime(date.timetuple()) + date.microsecond / 1e6
    return timestamp


def time_format(timestamp):
    datetime_tmp = datetime.datetime.fromtimestamp(timestamp)
    datetime_str = datetime_tmp.strftime('%Y-%m-%d-%H-%M-%S-%f')
    return datetime_str


def annotation_convert(annotations_track: List[Dict]):
    dst_anno = list()
    for anno in annotations_track:
        tmp = dict()
        property = dict()
        if anno['gt_names'] == "Vehicle":
            tmp["labeling_type"] = "PC_3D"
            tmp["category"] = category_map[anno['gt_names']]
            if anno['2d_subtype'] != -1:
                tmp["sub_category"] = vehicle_sub_category_map[anno['2d_subtype']]
                if anno['2d_subtype'] == 3:
                    tmp["category"] = "Tricycle"
                    tmp["sub_category"] = "Non-humanTricycle"
            else:
                tmp["sub_category"] = "PassengerCar"
            center = anno["gt_boxes"][:3]
            wlh = anno["gt_boxes"][3:6]
            yaw = [anno["gt_boxes"][6]]
            velocity = anno['gt_velocity']
            tmp["PC_3D"] = center + wlh + [0, 0] + yaw + velocity + [0]
            property["track_id"] = anno['track_id']
        elif anno['gt_names'] == "Pedestrian":
            tmp["labeling_type"] = "PC_3D"
            tmp["category"] = "Pedestrian"
            center = anno["gt_boxes"][:3]
            wlh = anno["gt_boxes"][3:6]
            yaw = [anno["gt_boxes"][6]]
            velocity = anno['gt_velocity']
            tmp["PC_3D"] = center + wlh + [0, 0] + yaw + velocity + [0]
            if wlh[-1] >= 1.5:
                tmp["sub_category"] = 'Adult'
            else:
                tmp["sub_category"] = 'Children'
            property["track_id"] = anno['track_id']
        elif anno['gt_names'] == "Cyclist":
            tmp["labeling_type"] = "PC_3D"
            tmp["category"] = "Two-wheels"
            center = anno["gt_boxes"][:3]
            wlh = anno["gt_boxes"][3:6]
            yaw = [anno["gt_boxes"][6]]
            velocity = anno['gt_velocity']
            tmp["PC_3D"] = center + wlh + [0, 0] + yaw + velocity + [0]
            tmp["sub_category"] = 'Bicycle'
            property["track_id"] = anno['track_id']
        property["uuid"] = ""
        property["instance_id"] = anno["index"]
        property["sensor_id"] = "PANDAR128"
        if anno['source'] in ['both', 'camera']:
            property["visible_in_cam"] = 1
        else:
            property["visible_in_cam"] = 0
        property["is_in_rows"] = 0
        property["is_tight"] = ""
        property["vehicle_size"] = ""
        property["marker_confidence"] = anno["detection_score"]
        property['source'] = anno['source']
        tmp["property"] = property
        dst_anno.append(tmp)
    return dst_anno


def work(content, content_index):
    #  主键
    label = dict()
    meta = dict()
    ego_kinematics = dict()
    ego_pose = dict()
    sensor = list()
    scene_info = dict()

    meta["spec_version"] = ""
    meta["req_version"] = ""
    meta["labeling_type"] = "autolabeled"
    meta["batch_id"] = content['batch_id']
    meta["frame_id"] = content['timestamp']
    meta["frame_index"] = str(content_index)
    meta["pre_frame"] = content["prev"]
    meta["next_frame"] = content["next"]
    meta["pre_sweeps"] = list()
    meta["next_sweeps"] = list()
    meta["ego_timestamp"] = content["timestamp"]


    ego_kinematics["INS_VelE"] = ""
    ego_kinematics["INS_VelN"] = ""
    ego_kinematics["INS_VelU"] = ""
    ego_kinematics["INS_VehicleGyroX"] = ""
    ego_kinematics["INS_VehicleGyroY"] = ""
    ego_kinematics["INS_VehicleGyroZ"] = ""
    ego_kinematics["INS_speed"] = ""
    meta["ego_kinematics"] = ego_kinematics

    roll, pitch, yaw = get_roll_pitch_yaw(content["ego2global_rotation"])
    ego_pose["roll"] = roll
    ego_pose["yaw"] = yaw
    ego_pose["pitch"] = pitch
    ego_pose["heading"] = ""
    ego_pose["x"] = content["ego2global_translation"][0]
    ego_pose["y"] = content["ego2global_translation"][1]
    ego_pose["z"] = content["ego2global_translation"][2]
    meta["ego_pose"] = ego_pose

    for cam in content["cams"]:
        cam_data = content["cams"][cam]
        tmp = dict()
        tmp["sensor_id"] = cam
        tmp["is_major"] = 0
        tmp["timestamp"] = cam_data["timestamp"]
        tmp["height"] = ""
        tmp["width"] = ""
        tmp["channel"] = ""
        tmp["sensorFOV"] = ""
        tmp["sensor_data_undistort"] = cam_data["filename"]
        tmp["data_path_undistort"] = cam_data["data_path"]
        tmp["sensor_data"] = cam_data["filename"].split(".")[0] + "_undistort.jpeg"
        tmp["data_path"] = "/clever/volumes/bev-data/es33_datasets/Images/" + content["timestamp"] + "/" + tmp["sensor_data"]
        sensor_param = dict()
        sensor_param["camera_model"] = "pinhole"
        sensor_param["intrinsic"] = cam_data["camera_intrinsic"]
        sensor_param["sensor2ego_rotation"] = cam_data["sensor2ego_rotation"]
        sensor_param["sensor2ego_translation"] = cam_data["sensor2ego_translation"]
        sensor_param["need_distort"] = True
        sensor_param["distort"] = cam_data["distort"]
        # sensor_param["ego2global_rotation"] = cam_data["ego2global_rotation"]
        # sensor_param["ego2global_translation"] = cam_data["ego2global_translation"]
        sensor_param["ego2global_rotation"] = ""
        sensor_param["ego2global_translation"] = ""
        tmp["sensor_param"] = sensor_param
        sensor.append(tmp)

    panda_info = dict()
    panda_info["sensor_id"] = "Pandar128"
    panda_info["is_major"] = 1
    panda_info["timestamp"] = ""
    panda_info["timestamp_comp"] = ""
    panda_info["point_feature_num"] = ""
    panda_info["width"] = ""
    panda_info["height"] = ""
    panda_info["sensorFOV"] = 360
    panda_info["environment_noise"] = ""
    panda_info["sensor_data"] = content["lidar_path"].split("/")[-1]
    panda_info["data_path"] = content["lidar_path"]
    panda_sensor_param = dict()
    panda_sensor_param["sensor2ego_rotation"] = get_quaternion(content["lidar2ego_rotation"]).tolist()
    panda_sensor_param["sensor2ego_translation"] = content["lidar2ego_translation"]
    panda_sensor_param["ego2global_rotation"] = ""
    panda_sensor_param["ego2global_translation"] = ""
    panda_info["sensor_param"] = panda_sensor_param
    sensor.append(panda_info)
    meta["sensor"] = sensor

    scene_info["light_and_weather"] = ""
    scene_info["road_condition"] = ""
    scene_info["environment_condition"] = ""
    scene_info["ego_and_obstacle_state"] = ""
    meta["scene_info"] = scene_info
    label["meta"] = meta

    annotations = annotation_convert(content["annotations_track"])
    label["annotations"] = annotations
    return label

class NumpyArrayEncoder(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, np.ndarray):
            return obj.tolist()
        if isinstance(obj, np.float32):
            return float(obj)
        if isinstance(obj, np.float):
            return float(obj)
        if isinstance(obj, np.integer):
            return int(obj)
        return json.JSONEncoder.default(self, obj)


if __name__ == "__main__":

    data_file = './mot_results_v6/20221213104122200_to_20221213104733400_track_merge.pkl'
    save_path = './mot_results_v6/results_json_new/'
    os.makedirs(save_path, exist_ok=True)

    with open(data_file, 'rb') as f:
        data_dets = pickle.load(f)

    segment_names = sorted(list(data_dets.keys()))
    for segment_name in segment_names:
        save_path_seg = os.path.join(save_path, segment_name)
        os.makedirs(save_path_seg, exist_ok=True)
        for frame_index, frame_data in enumerate(data_dets[segment_name]):
            timestamp = frame_data['timestamp']
            frame_file = os.path.join(save_path_seg, timestamp+'.json')
            label_formated = work(frame_data, frame_index)
            json_str = json.dumps(label_formated, cls=NumpyArrayEncoder, indent=4)
            with open(frame_file, "w") as f:
                f.write(json_str)
                f.close()


    # source_path = "/newpart/datasets/results_json"
    # dst_path = "/newpart/datasets/train"
    # if not os.path.exists(dst_path):
    #     os.mkdir(dst_path)
    # os.chdir(source_path)
    # trin_num = len(os.listdir(source_path)) * 0.8
    # i = 0
    # for folder in os.listdir(os.getcwd()):
    #     json_folder = os.path.join(source_path, folder)
    #     if i > trin_num:
    #         dst_path = "/newpart/datasets/val"
    #         if not os.path.exists(dst_path):
    #             os.mkdir(dst_path)
    #     for json_file in os.listdir(json_folder):
    #         json_path = os.path.join(json_folder, json_file)
    #         f = open(json_path)
    #         content = json.load(f)
    #         label = work(content)
    #         with open(os.path.join(dst_path, json_file), "w") as f:
    #             json.dump(label, f)
    #             f.close()
    #         i += 1
