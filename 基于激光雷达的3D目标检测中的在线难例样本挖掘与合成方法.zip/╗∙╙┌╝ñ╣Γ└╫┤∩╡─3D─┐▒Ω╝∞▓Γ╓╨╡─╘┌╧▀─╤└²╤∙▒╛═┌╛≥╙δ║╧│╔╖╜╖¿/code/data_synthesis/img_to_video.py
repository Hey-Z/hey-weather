import cv2
import os

# 设置输入文件夹路径和输出视频名称
input_folder = '/opt/dataset/bev-test/20231201-20231130-car2-bevtest-Lidar-20231130_152541_posefixed_3/res/track_imgs/demo/vehicle'
output_video = '/opt/dataset/bev-test/20231201-20231130-car2-bevtest-Lidar-20231130_152541_posefixed_3/res/track_imgs/demo/output.mp4'

# 获取所有图像的文件名列表
image_files = [f for f in sorted(os.listdir(input_folder)) if f.endswith('.png')]
image_files = sorted(image_files, key=lambda x: int(x.split('.')[0]))

# 读取第一张图像并获取其大小信息
frame = cv2.imread(os.path.join(input_folder, image_files[0]))
height, width, layers = frame.shape

# 创建VideoWriter对象，指定编码器、分辨率等参数
fourcc = cv2.VideoWriter_fourcc(*"mp4v")
out = cv2.VideoWriter(output_video, fourcc, 3.0, (width, height))

# 遍历每张图像，写入到视频中
for image_file in image_files:
    img_path = os.path.join(input_folder, image_file)
    frame = cv2.imread(img_path)

    # 如果需要调整图像大小，则进行相应操作
    # resized_frame = cv2.resize(frame, (new_width, new_height))

    out.write(frame)

# 释放VideoWriter对象及关闭视频流
out.release()
cv2.destroyAllWindows()