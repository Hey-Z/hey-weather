#!/usr/bin/env bash

input_dir=$1
output_dir=$2
sample_ratio=$3

emb_path=$(python encoder.py --batch_size=8 --input_path=$input_dir --output_path=$output_dir)

python sampler.py --ratio=$sample_ratio --input_path=$emb_path --output_path=$output_dir