#! coding: utf-8

import os
import datetime
import argparse
import numpy as np

from encoder import encode
from sampler import sampling

import warnings
warnings.filterwarnings('ignore')


def parse_config():
    parser = argparse.ArgumentParser(description='arg parser')
    # 和embeddig相关的参数
    parser.add_argument('--batch_size', type=int, default=4, help='batch size for inference')
    parser.add_argument('--workers', type=int, default=4, help='number of workers for dataloader')
    parser.add_argument('--ckpt', type=str, default=None, help='checkpoint to start from')

    # 和sampling相关的参数
    parser.add_argument('--ratio', type=float, help='sample ratio, eg. 0.3/0.5/0.7')
    parser.add_argument('--decomposition', type=str, default='pca', help='decomposition method')
    parser.add_argument('--n_components', type=int, default=2, help='components of decomposition method')

    parser.add_argument('--input_path', type=str, help='images directory')
    parser.add_argument('--output_path', type=str, help='directory for sampling results to save')
    parser.add_argument('--save', action='store_true', help='whether to save the results or not')
    args = parser.parse_args()

    return args


def main():
    args = parse_config()
    args.ckpt = './checkpoint/backbone_model.pt'
    args.ratio = 0.3
    args.input_path = 'data/'
    args.output_path = 'res/'
    input_path = args.input_path
    output_path = args.output_path

    embs, fnames = encode(ckpt=args.ckpt, input_path=input_path, args=args)

    res = sampling(np.array(embs), np.array(fnames), ratio=args.ratio, decomposition=args.decomposition, args=args)

    if args.save:
        if not os.path.exists(output_path):
            os.makedirs(output_path, exist_ok=True)

        save_path = os.path.join(output_path, datetime.datetime.strftime(datetime.datetime.now(), '%Y-%m-%d-%H:%M:%S')
                                 + f'_coreset_{args.ratio}_{args.decomposition}.txt')
        np.savetxt(save_path, res, delimiter='\n', fmt='%s')

    else:
        print('[INFO] process done! The result is: \n', res)


if __name__ == '__main__':
    main()
