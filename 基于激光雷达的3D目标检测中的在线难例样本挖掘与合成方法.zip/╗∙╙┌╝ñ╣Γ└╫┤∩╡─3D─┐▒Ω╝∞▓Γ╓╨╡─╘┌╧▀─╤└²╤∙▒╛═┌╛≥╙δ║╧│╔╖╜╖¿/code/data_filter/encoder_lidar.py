
import argparse
import os
from PIL import Image
import torchvision
import lightly.data as data
import pandas as pd
import torch
from tqdm import tqdm
from pathlib import Path
import datetime
from torch.utils.data import Dataset, DataLoader

_SUFFIX = ['.jpg', '.jpeg', '.bmp', '.png', '.pgm']

class SimCLRDataset(Dataset):
    def __init__(self, data_dir, resize=512):
        super().__init__()

        self.resize = resize

        files = list(Path(data_dir).rglob('*'))
        self.images = [os.path.abspath(str(file)) for file in files if file.suffix.lower() in _SUFFIX]  # 获取文件夹中所有的图像文件

    def __len__(self):
        return len(self.images)

    def __getitem__(self, index):
        image_path = self.images[index]
        image = Image.open(image_path)
        img = get_test_transform(self.resize)(image)

        data_dict = {
            'image': img,
            'filename': image_path
        }
        return data_dict

def parse_config():
    parser = argparse.ArgumentParser(description='arg parser')
    parser.add_argument('--batch_size', type=int, default=4, help='batch size for inference')
    parser.add_argument('--workers', type=int, default=4, help='number of workers for dataloader')
    parser.add_argument('--ckpt', type=str, default=None, help='checkpoint to start from')

    parser.add_argument('--input_path', type=str, default=None, help='images directory')
    parser.add_argument('--output_path', type=str, default=None, help='directory for embeddings to save')
    args = parser.parse_args()

    return args

def get_test_transform(input_size):
    return torchvision.transforms.Compose([
        torchvision.transforms.Resize((input_size, input_size)),
        torchvision.transforms.ToTensor(),
        torchvision.transforms.Normalize(
            mean=data.collate.imagenet_normalize['mean'],
            std=data.collate.imagenet_normalize['std']
        )
    ])

def to_numpy(tensor):
    return tensor.detach().cpu().numpy() if tensor.requires_grad else tensor.cpu().numpy()

def build_dataloader(data_dir, args):
    dataset = SimCLRDataset(data_dir)
    dataloader = DataLoader(
        dataset,
        batch_size=args.batch_size,
        num_workers=args.workers,
    )

    return dataloader

def get_embeddings(model_path, data_dir, args):
    model = torch.load(model_path)
    model = model[1:]
    model.eval()
    if torch.cuda.is_available():
        model.cuda()

    embeddings = []
    fnames = []

    # files = list(Path(data_dir).rglob('*'))
    # images = [str(file) for file in files if file.suffix.lower() in _SUFFIX]  # 获取文件夹中所有的图像文件

    dataloader = build_dataloader(data_dir, args)
    for i, batch in enumerate(dataloader):
        imgs = batch['image']
        filenames = batch['filename']

        batch_size = len(imgs)

        if torch.cuda.is_available():
            imgs = imgs.cuda()

        embeds = model(imgs)  # 输出64维向量

        fnames.extend(filenames)
        embeddings.extend(to_numpy(embeds.reshape(batch_size, 64)))

    return embeddings, fnames

def main():
    args = parse_config()
    args.ckpt = './checkpoint/backbone_model.pt'
    args.input_path = './data'
    args.output_path = './'
    embs, fnames = get_embeddings(args.ckpt, args.input_path, args)

    assert len(embs) == len(fnames), 'embeddings must be equal with filenames!'

    embs = pd.DataFrame(embs)
    fnames = pd.DataFrame(fnames, columns=['fpath'])
    df = pd.concat([embs, fnames], axis=1)  # 前64维是向量，最后一维是图像名称

    # 保存路径
    spath = os.path.join(args.output_path, datetime.datetime.strftime(datetime.datetime.now(), '%Y-%m-%d-%H:%M:%S') + '_embs.csv')
    df.to_csv(spath)

    return spath

if __name__ == '__main__':
    from sklearn.decomposition import PCA, KernelPCA, IncrementalPCA, SparsePCA, MiniBatchSparsePCA, SparseCoder
    demo_embs = np.random.random((150000, 64))
    # demo_embs = demo_embs.reshape((150000, -1))

    start = time.time()
    model = PCA(n_components=16)
    proj = model.fit_transform(demo_embs)
    print('PCA: ', time.time() - start)

    # model = KernelPCA(n_components=16)  #
    # proj2 = model.fit_transform(demo_embs)
    # print('KernelPCA: ', time.time() - start)
    #
    # model = SparsePCA(n_components=16)
    # proj3 = model.fit_transform(demo_embs)
    # print('SparsePCA: ', time.time() - start)
    #
    # model = MiniBatchSparsePCA(n_components=16)
    # proj4 = model.fit_transform(demo_embs)
    # print('MiniBatchSparsePCA: ', time.time() - start)
    #
    # model = IncrementalPCA(n_components=16)
    # proj5 = model.fit_transform(demo_embs)
    # print('IncrementalPCA: ', time.time() - start)
