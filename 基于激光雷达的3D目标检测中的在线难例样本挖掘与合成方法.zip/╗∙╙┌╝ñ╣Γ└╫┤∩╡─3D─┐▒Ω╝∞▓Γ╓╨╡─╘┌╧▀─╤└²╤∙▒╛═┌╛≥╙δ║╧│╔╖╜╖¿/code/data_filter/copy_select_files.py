#! coding: utf-8

import argparse
import os
import shutil

import pandas as pd



def parse_config():
    parser = argparse.ArgumentParser(description='arg parser')
    parser.add_argument('--input_path', type=str, default=None, help='images directory')
    parser.add_argument('--output_path', type=str, default=None, help='directory for embeddings to save')
    args = parser.parse_args()

    return args

def main():
    args = parse_config()
    args.input_path = '/opt/dataset/test_for_select/scene_3_embs/2023-10-13-17:17:38_graph_density_0.1_pca.csv'
    args.output_path = '/opt/dataset/test_for_select/scene_3_filtered/graph_density_0.1'
    select_filenames = pd.read_csv(args.input_path, index_col=0)
    for i in range(len(select_filenames)):
        file = select_filenames.iloc[i, 0]
        filename = file.split('/')[-1]
        dst_path = os.path.join(args.output_path, filename)
        if not os.path.exists(args.output_path):
            os.makedirs(args.output_path, exist_ok=True)
        shutil.copy(file, dst_path)

if __name__ == '__main__':
    main()