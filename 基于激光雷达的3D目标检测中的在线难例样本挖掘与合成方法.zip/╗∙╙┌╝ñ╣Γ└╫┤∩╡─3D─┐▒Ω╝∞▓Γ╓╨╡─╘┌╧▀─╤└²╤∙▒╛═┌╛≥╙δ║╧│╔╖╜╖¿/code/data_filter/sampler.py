#! coding: utf-8

import os
import datetime
import argparse
import time

import numpy as np
import pandas as pd
import sklearn.svm

from activelearninggoogle.sampling_methods.kcenter_greedy import kCenterGreedy
from activelearninggoogle.sampling_methods.graph_density import GraphDensitySampler
# from activelearninggoogle.sampling_methods.uniform_sampling import UniformSampling  # 随机采样
from activelearninggoogle.sampling_methods.margin_AL import MarginAL
from activelearninggoogle.sampling_methods.kmeans_sampling import KmeansSampler
from activelearninggoogle.sampling_methods.informative_diverse import InformativeClusterDiverseSampler

# from activelearninggoogle.utils.utils import get_model

from sklearn.decomposition import PCA
from sklearn.manifold import TSNE
from sklearn.cluster import KMeans
from sklearn.svm import SVC


def parse_config():
    parser = argparse.ArgumentParser(description='arg parser')
    parser.add_argument('--ratio', type=float, default=0.3, help='sample ratio')
    parser.add_argument('--decomposition', type=str, default='pca', help='decomposition method')
    parser.add_argument('--n_components', type=int, default=2, help='components of decomposition method')

    parser.add_argument('--input_path', type=str, default=None, help='images directory')
    parser.add_argument('--output_path', type=str, default=None, help='directory for embeddings to save')
    parser.add_argument('--save', action='store_true', default=True, help='whether to save the results or not')
    args = parser.parse_args()

    return args


def myDecomposition(embs, decomposition, args):
    # 降维
    if decomposition == 'pca':
        transformer = PCA(n_components=args.n_components)
    elif decomposition == 'tsne':
        transformer = TSNE(n_components=args.n_components)
    else:
        print(f'unsupported decomposition method: {decomposition}, only support pca and tsne!')
        return None

    projection = transformer.fit_transform(embs)

    return projection

def coreset_sample(embs, fnames, ratio=0.3, decomposition='pca', args=None):
    # 降维
    proj = myDecomposition(embs, decomposition, args)

    # 构建采样器
    index = [i for i in range(len(proj))]
    mySampler = kCenterGreedy(proj, index, seed=0)

    # 采样
    select = mySampler.select_batch_(int(len(proj) * ratio), already_selected=[])

    # 后处理，索引-->文件路径
    filepaths = fnames[select]

    # if args.save:
    #     filepaths.to_csv(os.path.join(args.output_path, datetime.datetime.strftime(datetime.datetime.now(),
    #                                                                       '%Y-%m-%d-%H:%M:%S') + f'_coreset_{ratio}_{decomposition}.csv'))

    return filepaths

def graph_density_sample(embs, fnames, ratio=0.3, decomposition='pca', args=None):
    # 降维
    proj = myDecomposition(embs, decomposition, args)

    # 构建采样器
    index = [i for i in range(len(proj))]
    mySampler = GraphDensitySampler(proj, index, seed=0)

    # 采样
    select = mySampler.select_batch_(int(len(proj) * ratio), already_selected=[])

    # 后处理，索引-->文件路径
    filepaths = fnames[select]

    if args.save:
        filepaths.to_csv(os.path.join(args.output_path, datetime.datetime.strftime(datetime.datetime.now(),
                                                                                   '%Y-%m-%d-%H:%M:%S') + f'_graph_density_{ratio}_{decomposition}.csv'))

    return filepaths

# todo: debug
def margin_sample(embs, fnames, ratio=0.3, decomposition='pca', model_name='kernel_svm', args=None):
    '''
    :param model_name: 决策边界分类模型(sklearn)
    '''
    # 降维
    proj = myDecomposition(embs, decomposition, args)

    # 构建采样器
    index = [i for i in range(len(proj))]
    mySampler = MarginAL(proj, index, seed=0)

    # 构建决策边界分类器
    # margin采样需要先有一个分类模型，计算分类模型的输出probs，sorted(probs)，然后将probs[0] - probs[1]作为采样的评判标准
    cluster = KMeans(n_clusters=int(len(proj) * ratio))
    cluster.fit(proj)
    labels = cluster.labels_
    model = SVC()
    model.fit(proj, labels)

    # 采样
    select = mySampler.select_batch_(model=model, already_selected=[], N=int(len(proj) * ratio))

    # 后处理，索引-->文件路径
    filepaths = fnames[select]

    if args.save:
        filepaths.to_csv(os.path.join(args.output_path, datetime.datetime.strftime(datetime.datetime.now(),
                                                                                   '%Y-%m-%d-%H:%M:%S') + f'_margin_{ratio}_{decomposition}.csv'))

    return filepaths

def kmeans_sample(embs, fnames, ratio=0.3, decomposition='pca', args=None):
    # 降维
    proj = myDecomposition(embs, decomposition, args)

    # 构建采样器
    index = [i for i in range(len(proj))]
    mySampler = KmeansSampler(proj, index, seed=0)

    # 采样
    select = mySampler.select_batch_(int(len(proj) * ratio), already_selected=[])

    # 后处理，索引-->文件路径
    filepaths = fnames[select]

    if args.save:
        filepaths.to_csv(os.path.join(args.output_path, datetime.datetime.strftime(datetime.datetime.now(),
                                                                                   '%Y-%m-%d-%H:%M:%S') + f'_kmeans_{ratio}_{decomposition}.csv'))

    return filepaths

# todo: debug
def informative_and_diverse_sample(embs, fnames, ratio=0.3, decomposition='pca', args=None):
    # 降维
    proj = myDecomposition(embs, decomposition, args)

    # 构建采样器
    index = [i for i in range(len(proj))]
    mySampler = InformativeClusterDiverseSampler(proj, index, seed=0)

    cluster = KMeans(n_clusters=int(len(proj) * ratio))
    cluster.fit(proj)
    labels = cluster.labels_
    model = SVC()
    model.fit(proj, labels)

    # 采样
    select = mySampler.select_batch_(model, already_selected=[], N=int(len(proj) * ratio))

    # 后处理，索引-->文件路径
    filepaths = fnames[select]

    if args.save:
        filepaths.to_csv(os.path.join(args.output_path, datetime.datetime.strftime(datetime.datetime.now(),
                                                                                   '%Y-%m-%d-%H:%M:%S') + f'_kmeans_{ratio}_{decomposition}.csv'))

    return filepaths

def exp3bandit_sampler(embs, fnames, ratio=0.3, decomposition='pca', args=None):
    pass


def load_embeddings(embs_path):
    df = pd.read_csv(embs_path, index_col=0)
    embeddings = df.iloc[:, :64]
    fnames = df.iloc[:, -1]
    return embeddings, fnames

def sampling(embs, fnames, ratio, decomposition, args):
    coreset_res = coreset_sample(embs, fnames, ratio, decomposition, args)
    return coreset_res

def main():
    args = parse_config()
    args.ratio = 0.7
    args.input_path = '2023-11-03-17:01:52_embs.csv'
    args.output_path = './'

    embeddings, fnames = load_embeddings(args.input_path)

    coreset_res = coreset_sample(embeddings, fnames, args.ratio, args.decomposition, args)
    # graph_density_res = graph_density_sample(embeddings, fnames, args.ratio, args.decomposition, args)
    # print(f'graph density result: {graph_density_res}')

    # margin_res = margin_sample(embs=embeddings, fnames=fnames, ratio=args.ratio, decomposition=args.decomposition, args=args)
    # print(f'margin sample results: \n{margin_res}')

    # ids_res = informative_and_diverse_sample(embs=embeddings, fnames=fnames, ratio=args.ratio, decomposition=args.decomposition, args=args)
    # print(f'informative and diverse sample results: \n{ids_res}')

    kmeans_res = kmeans_sample(embs=embeddings, fnames=fnames, ratio=args.ratio, decomposition=args.decomposition, args=args)
    print(f'kmeans sample results: \n{kmeans_res}')

    return coreset_res


if __name__ == '__main__':
    start = time.time()
    res = main()
    end = time.time()
    print('time consumes: ', end - start)
    print(f'[INFO] {datetime.datetime.now()} CoreSet sampling result: \n{res}')
