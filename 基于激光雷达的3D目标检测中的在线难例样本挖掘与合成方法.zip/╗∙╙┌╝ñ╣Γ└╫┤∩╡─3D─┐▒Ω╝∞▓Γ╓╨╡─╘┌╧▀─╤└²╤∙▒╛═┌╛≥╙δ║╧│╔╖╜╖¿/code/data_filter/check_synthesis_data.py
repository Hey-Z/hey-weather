import os
import cv2
import numpy as np
from scipy.spatial.transform import Rotation as R
from nuscenes.utils.data_classes import Box
from pyquaternion import Quaternion
import json
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
import argparse
import glob
from pathlib import Path
from tmp_module import get_json_parameters
from pyquaternion import Quaternion

camera_name = ['CAM_FRONT', 'CAM_REAR', 'CAM_LEFT', 'CAM_RIGHT']
cam_size = {
    'CAM_FRONT': [1920, 1536],
    'CAM_REAR': [1920, 1536],
    'CAM_LEFT': [1920, 1536],
    'CAM_RIGHT': [1920, 1536]
}

draw_boxes_indexes_img_view = [(0, 1), (1, 2), (2, 3), (3, 0),
                               (4, 5), (5, 6), (6, 7), (7, 4),
                               (0, 4), (1, 5), (2, 6), (3, 7)]

sub_color_map = {
    'pillars': (255, 255, 0), # 黄色
    'cars': (0, 255, 0), # 绿色,
    'obstacles': (156, 102, 31), # 砖红色
    'barriers': (0, 0, 255),
    'shopping_carts': (255, 0, 0),
    'locks': (255, 0, 255)
}

map_cam = {
    'CAM_FRONT': 'front',
    'CAM_REAR': 'rear',
    'CAM_LEFT': 'left',
    'CAM_RIGHT': 'right'
}


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument('--calibration', type=str, help='calibration file path')
    parser.add_argument('--annotation', type=str, help='annotations file directory')
    parser.add_argument('--map', type=str, help='map json file path')
    parser.add_argument('--image', type=dir, help='image file directory')

    parser.add_argument('--draw_2d_box', type=str, default=True, help='whether to draw 2d boxes on image or not')
    parser.add_argument('--draw_3d_box', type=str, default=False, help='if draw_2d_box=False, it works;')

    parser.add_argument('--save_dir', type=str, help='save directory')

    args = parser.parse_args()

    return args

def _is_visible(corners_2d, corners_3d, corners_3d_z_min_sensor, corners_3d_z_max_sensor, imsize):
    visible = np.logical_and(
        corners_2d[:, 0] > 0, corners_2d[:, 0] < imsize[0]
    )
    visible = np.logical_and(visible, corners_2d[:, 1] < imsize[1])
    visible = np.logical_and(visible, corners_2d[:, 1] > 0)
    visible = np.logical_and(visible, corners_3d[:, 2] > 1)
    # visible = np.logical_and(visible, corners_3d_z_min_sensor > 0 or corners_3d_z_max_sensor > 0)
    visible = np.logical_and(visible, corners_3d_z_max_sensor > 0)
    return any(visible)


def main(args):

    calib_dir = args.calibration
    calib_files = Path(calib_dir).rglob('*.json')
    calibs = {}
    for calib_file in calib_files:
        fname = str(calib_file).split('/')[-1]
        cname, suffix = fname.split('.')
        _, cid = cname.split('_')
        with open(str(calib_file)) as fp:
            calibs[camera_name[int(cid)]] = json.load(fp)

    anno_dir = args.annotation
    anno_files = list(Path(anno_dir).rglob('*.json'))
    anno_files = sorted(anno_files, key=lambda x: int(str(x).split('/')[-1].split('_')[0]))
    for anno_file in anno_files:
        # anno_file = Path('/opt/dataset/e2e_synthesis_data/e2e/labels/0_annotation.json')  # debug
        # 读取当前帧标注文件
        aname = str(anno_file).split('/')[-1]
        aid, _ = aname.split('.')[0].split('_')
        print('frame: ', aid)
        with open(anno_file) as fp:
            annos = json.load(fp)

            ego_pose = annos['ego_pose']
            ego_t = ego_pose['pose']
            ego_r = ego_pose['angular_rate']
            e2g = np.eye(4)
            e2g[:3, :3] = R.from_rotvec(ego_r).as_matrix()
            e2g[:3, 3] = ego_t
            g2e = np.linalg.inv(e2g)

        # 将标注分别投影到对应相机中
        for cname in camera_name:
            print('camera: ', cname)
            image_file = Path(args.image)/f'fisheye_{aid}_{cname}.png'
            img = cv2.imread(str(image_file))

            calib = calibs[cname]
            calib_param = get_json_parameters(calib)
            r = calib_param['sensor2ego_rotation']
            r_matrix = Quaternion(r).rotation_matrix
            t = calib_param['sensor2ego_translation']
            intrinsic = np.array(calib_param['intrinsic'])
            distort = np.array(calib_param['distort'])

            cam2ego = np.eye(4)
            cam2ego[:3, :3] = r_matrix
            cam2ego[:3, 3] = t

            ego2cam = np.linalg.inv(cam2ego)

            viewpad = np.eye(4)
            viewpad[: intrinsic.shape[0], : intrinsic.shape[1]] = intrinsic
            ego2img = viewpad @ ego2cam

            for j, anno in enumerate(annos['annotations']):
                pos = anno['pose']
                size = anno['size']
                # size[-1] = size[-1] - 0.2
                yaw = anno['rotation'][-1]
                category = anno['category']
                box = Box([pos[0], pos[1], pos[2] + size[-1] / 2], size, Quaternion(axis=[0, 0, 1], radians=yaw),
                          name=category)
                corners = box.corners()  # 3*8

                corners_ego = g2e.dot(np.concatenate((corners, np.ones((1, 8), dtype=corners.dtype))))[:3, :]
                corners_3d = corners_ego.transpose(1, 0)[None, :]

                rvec, _ = cv2.Rodrigues(ego2cam[:3, :3])
                tvec = ego2cam[:3, 3]
                corners_2d, _ = cv2.fisheye.projectPoints(corners_3d, rvec=rvec, tvec=tvec,
                                                          K=intrinsic, D=distort)
                corners_2d = corners_2d.squeeze()
                corners_3d = corners_3d.squeeze()

                corners_3d_sensor_z = ego2cam.dot(np.concatenate((corners_ego, np.ones((1, 8), dtype=corners.dtype))))[
                    2]
                # todo: 两种投影策略，3D投2D全框才保留（可能匹配更安全/精准？）；3D投2D漏出来就保留（为了填充visible_in_cams字段和在子图上画图更完整）
                corners_3d_z_max_sensor = np.max(corners_3d_sensor_z)  # max是只要投过来在图片上显示了就保留，min是投过来完整框才保留
                corners_3d_z_min_sensor = np.min(corners_3d_sensor_z)  # 匹配的时候还是要按照全框来匹配

                if not _is_visible(corners_2d, corners_3d, corners_3d_z_min_sensor, corners_3d_z_max_sensor, cam_size[cname]):
                    continue

                corners_2d[..., 0] = np.clip(corners_2d[..., 0], 0, cam_size[cname][0] - 1)
                corners_2d[..., 1] = np.clip(corners_2d[..., 1], 0, cam_size[cname][1] - 1)

                corners_2d = corners_2d.astype(np.int32)

                box2d = np.array([
                    min(corners_2d[:, 0]),
                    min(corners_2d[:, 1]),
                    max(corners_2d[:, 0]),
                    max(corners_2d[:, 1])
                ])

                if args.draw_2d_box:
                    cv2.rectangle(img, (box2d[0], box2d[1]), (box2d[2], box2d[3]), color=(255, 97, 0))
                    cv2.putText(img, str(category) + f'_{j}', (box2d[0], box2d[1]), cv2.FONT_HERSHEY_SIMPLEX, 0.5,
                                (92, 92, 205), thickness=1)
                else:
                   if args.draw_3d_box:
                        for index in draw_boxes_indexes_img_view:
                            cv2.line(img,
                                     corners_2d[index[0]],
                                     corners_2d[index[1]],
                                     # color=color_map[box_info['gt_names']],
                                     color=sub_color_map[category],  # 根据子类别画框
                                     thickness=1)

            cv2.imwrite(os.path.join(args.save_dir, f'frame_{aid}_{cname}.png'), img)

    image_dir = args.image
    image_files = Path(image_dir).rglob('*.png')

def main2(args):
    # 图像去畸变，然后将3D框投影到去畸变图上
    calib_dir = args.calibration
    calib_files = Path(calib_dir).rglob('*.json')
    calibs = {}
    for calib_file in calib_files:
        fname = str(calib_file).split('/')[-1]
        cname, suffix = fname.split('.')
        _, cid = cname.split('_')
        with open(str(calib_file)) as fp:
            calibs[camera_name[int(cid)]] = json.load(fp)

    anno_dir = args.annotation
    anno_files = list(Path(anno_dir).rglob('*.json'))
    anno_files = sorted(anno_files, key=lambda x: int(str(x).split('/')[-1].split('_')[0]))
    for anno_file in anno_files:
        # anno_file = Path('/opt/dataset/e2e_synthesis_data/e2e/labels/0_annotation.json')  # debug
        # 读取当前帧标注文件
        aname = str(anno_file).split('/')[-1]
        aid, _ = aname.split('.')[0].split('_')
        print('frame: ', aid)
        with open(anno_file) as fp:
            annos = json.load(fp)

            ego_pose = annos['ego_pose']
            ego_t = ego_pose['pose']
            ego_r = ego_pose['angular_rate']
            e2g = np.eye(4)
            e2g[:3, :3] = R.from_rotvec(ego_r).as_matrix()
            e2g[:3, 3] = ego_t
            g2e = np.linalg.inv(e2g)

        # 将标注分别投影到对应相机中
        for cname in camera_name:
            print('camera: ', cname)
            image_file = Path(args.image) / f'fisheye_{aid}_{cname}.png'
            img = cv2.imread(str(image_file))

            calib = calibs[cname]
            calib_param = get_json_parameters(calib)
            r = calib_param['sensor2ego_rotation']
            r_matrix = Quaternion(r).rotation_matrix
            t = calib_param['sensor2ego_translation']
            intrinsic = np.array(calib_param['intrinsic'])
            distort = np.array(calib_param['distort'])

            newK, roi = cv2.getOptimalNewCameraMatrix(intrinsic, distort, (img.shape[1], img.shape[0]), 0, (img.shape[1], img.shape[0]))
            map1, map2 = cv2.fisheye.initUndistortRectifyMap(intrinsic, distort, np.eye(3), newK, (img.shape[1], img.shape[0]), cv2.CV_16SC2)
            # img_undistort = cv2.remap(img, map1, map2, cv2.INTER_LINEAR)
            img_undistort = cv2.fisheye.undistortImage(img, intrinsic, distort, np.eye(3), newK, (img.shape[1], img.shape[0]))
            # img_undistort = cv2.omnidir.undistortImage(img, intrinsic, distort, np.array([0.5]), 1, newK)
            # cv2.imwrite(os.path.join(args.save_dir, f'frame_{aid}_{cname}_undistort.png'), img_undistort)

            cam2ego = np.eye(4)
            cam2ego[:3, :3] = r_matrix
            cam2ego[:3, 3] = t

            ego2cam = np.linalg.inv(cam2ego)

            viewpad = np.eye(4)
            # viewpad[: intrinsic.shape[0], : intrinsic.shape[1]] = intrinsic  # bug;去完畸变后，要用新的内参
            viewpad[: intrinsic.shape[0], : intrinsic.shape[1]] = newK
            ego2img = viewpad @ ego2cam

            for j, anno in enumerate(annos['annotations']):
                # if j == 172:
                #     print(anno['uuid'])
                pos = anno['pose']
                size = anno['size']
                yaw = anno['rotation'][-1]
                category = anno['category']
                if category != 'pillars':
                    continue

                box = Box([pos[0], pos[1], pos[2] + size[-1] / 2], size, Quaternion(axis=[0, 0, 1], radians=yaw),
                          name=category)
                corners = box.corners()  # 3*8

                corners_3d = g2e.dot(np.concatenate((corners, np.ones((1, 8), dtype=corners.dtype))))

                # corners_3d = corners_ego[:3, :].transpose(1, 0)[None, :]
                corners_3d_z_min_sensor = np.min(ego2cam.dot(corners_3d)[2])
                corners_3d_z_max_sensor = corners_3d_z_min_sensor  # 正常相机策略不改变

                corners_3d = ego2img.dot(corners_3d)
                corners_3d[2, ...] = np.clip(corners_3d[2, ...], a_min=0.05, a_max=np.max(corners_3d))

                corners_2d = corners_3d[:3, :]

                corners_2d = corners_2d / corners_2d[2:3, :].repeat(3, 0).reshape(3, 8)

                corners_3d = np.transpose(corners_3d, (1, 0))
                corners_2d = np.transpose(corners_2d[:2, :], (1, 0))

                if not _is_visible(corners_2d, corners_3d, corners_3d_z_min_sensor, corners_3d_z_max_sensor,
                                   cam_size[cname]):
                    continue

                corners_2d[..., 0] = np.clip(corners_2d[..., 0], 0, cam_size[cname][0] - 1)
                corners_2d[..., 1] = np.clip(corners_2d[..., 1], 0, cam_size[cname][1] - 1)

                corners_2d = corners_2d.astype(np.int32)

                box2d = np.array([
                    min(corners_2d[:, 0]),
                    min(corners_2d[:, 1]),
                    max(corners_2d[:, 0]),
                    max(corners_2d[:, 1])
                ])

                if args.draw_2d_box:
                    cv2.rectangle(img_undistort, (box2d[0], box2d[1]), (box2d[2], box2d[3]), color=(255, 97, 0))
                    cv2.putText(img_undistort, str(category) + f'_{j}', (box2d[0], box2d[1]), cv2.FONT_HERSHEY_SIMPLEX, 0.5,
                                (92, 92, 205), thickness=1)
                else:
                   if args.draw_3d_box:
                        for index in draw_boxes_indexes_img_view:
                            cv2.line(img_undistort,
                                     corners_2d[index[0]],
                                     corners_2d[index[1]],
                                     # color=color_map[box_info['gt_names']],
                                     color=sub_color_map[category],  # 根据子类别画框
                                     thickness=2)
                            cv2.putText(img_undistort, str(category) + f'_{j}',
                                (corners_2d[4]), cv2.FONT_HERSHEY_SIMPLEX, 1, sub_color_map[category], thickness=1)

            cv2.imwrite(os.path.join(args.save_dir, f'frame_{aid}_{cname}.png'), img_undistort)

            image_dir = args.image
            image_files = Path(image_dir).rglob('*.png')

def main3(args):
    # e2e2版本数据
    calib_path = args.calibration
    with open(calib_path) as fp:
        calibs_info = json.load(fp)

    calibs = {}
    for cur_cam, cur_calibs in calibs_info.items():
        calibs[cur_cam] = cur_calibs

    anno_dir = args.annotation
    anno_files = list(Path(anno_dir).rglob('*.json'))
    anno_files = sorted(anno_files, key=lambda x: int(str(x).split('/')[-1].split('_')[0]))
    for anno_file in anno_files:
        # anno_file = Path('/opt/dataset/e2e_synthesis_data/e2e/labels/0_annotation.json')  # debug
        # 读取当前帧标注文件
        aname = str(anno_file).split('/')[-1]
        aid, _ = aname.split('.')[0].split('_')
        print('frame: ', aid)
        with open(anno_file) as fp:
            annos = json.load(fp)

            ego_pose = annos['ego_pose']
            ego_t = ego_pose['pose']
            ego_r = ego_pose['angular_rate']
            e2g = np.eye(4)
            e2g[:3, :3] = R.from_rotvec(ego_r).as_matrix()
            e2g[:3, 3] = ego_t
            g2e = np.linalg.inv(e2g)

        # 将标注分别投影到对应相机中
        for cname in camera_name:
            print('camera: ', cname)
            image_file = Path(args.image) / f'fisheye_{aid}_{map_cam[cname]}.png'
            img = cv2.imread(str(image_file))

            calib_param = calibs[cname]
            # calib_param = get_json_parameters(calib)
            r = calib_param['sensor2ego_rotation']
            r_matrix = Quaternion(r).rotation_matrix
            t = calib_param['sensor2ego_translation']
            intrinsic = np.array(calib_param['intrinsic'])
            distort = np.array(calib_param['distort'])

            cam2ego = np.eye(4)
            cam2ego[:3, :3] = r_matrix
            cam2ego[:3, 3] = t

            ego2cam = np.linalg.inv(cam2ego)

            viewpad = np.eye(4)
            viewpad[: intrinsic.shape[0], : intrinsic.shape[1]] = intrinsic
            ego2img = viewpad @ ego2cam

            for j, anno in enumerate(annos['annotations']):
                pos = anno['pose']
                size = anno['size'] # l,w,h
                # size[-1] = size[-1] - 0.2
                yaw = anno['rotation'][-1]
                category = anno['category']
                box = Box(pos, size, Quaternion(axis=[0, 0, 1], radians=yaw),
                          name=category)
                corners = box.corners()  # 3*8

                corners_ego = g2e.dot(np.concatenate((corners, np.ones((1, 8), dtype=corners.dtype))))[:3, :]
                corners_3d = corners_ego.transpose(1, 0)[None, :]

                rvec, _ = cv2.Rodrigues(ego2cam[:3, :3])
                tvec = ego2cam[:3, 3]
                corners_2d, _ = cv2.fisheye.projectPoints(corners_3d, rvec=rvec, tvec=tvec,
                                                          K=intrinsic, D=distort)
                corners_2d = corners_2d.squeeze()
                corners_3d = corners_3d.squeeze()

                corners_3d_sensor_z = ego2cam.dot(np.concatenate((corners_ego, np.ones((1, 8), dtype=corners.dtype))))[
                    2]
                # todo: 两种投影策略，3D投2D全框才保留（可能匹配更安全/精准？）；3D投2D漏出来就保留（为了填充visible_in_cams字段和在子图上画图更完整）
                corners_3d_z_max_sensor = np.max(corners_3d_sensor_z)  # max是只要投过来在图片上显示了就保留，min是投过来完整框才保留
                corners_3d_z_min_sensor = np.min(corners_3d_sensor_z)  # 匹配的时候还是要按照全框来匹配

                if not _is_visible(corners_2d, corners_3d, corners_3d_z_min_sensor, corners_3d_z_max_sensor,
                                   cam_size[cname]):
                    continue

                corners_2d[..., 0] = np.clip(corners_2d[..., 0], 0, cam_size[cname][0] - 1)
                corners_2d[..., 1] = np.clip(corners_2d[..., 1], 0, cam_size[cname][1] - 1)

                corners_2d = corners_2d.astype(np.int32)

                box2d = np.array([
                    min(corners_2d[:, 0]),
                    min(corners_2d[:, 1]),
                    max(corners_2d[:, 0]),
                    max(corners_2d[:, 1])
                ])

                if args.draw_2d_box:
                    cv2.rectangle(img, (box2d[0], box2d[1]), (box2d[2], box2d[3]), color=(255, 97, 0))
                    cv2.putText(img, str(category) + f'_{j}', (box2d[0], box2d[1]), cv2.FONT_HERSHEY_SIMPLEX, 0.5,
                                (92, 92, 205), thickness=1)
                else:
                    if args.draw_3d_box:
                        for index in draw_boxes_indexes_img_view:
                            cv2.line(img,
                                     corners_2d[index[0]],
                                     corners_2d[index[1]],
                                     # color=color_map[box_info['gt_names']],
                                     color=sub_color_map[category],  # 根据子类别画框
                                     thickness=1)

            cv2.imwrite(os.path.join(args.save_dir, f'frame_{aid}_{cname}.png'), img)

if __name__ == '__main__':

    import cv2
    cur_img = cv2.imread('/opt/dataset/e2e_synthesis_data/e2e2/fisheye/fisheye_0_front.png')

    args = parse_args()
    # args.calibration = '/opt/dataset/e2e_synthesis_data/e2e/sensor'
    args.calibration = '/opt/dataset/e2e_synthesis_data/e2e2/sensor.json'

    # args.annotation = '/opt/dataset/e2e_synthesis_data/e2e/labels'
    args.annotation = '/opt/dataset/e2e_synthesis_data/e2e2/labels2'

    # args.map = '/opt/dataset/e2e_synthesis_data/e2e/map.json'
    args.map = '/opt/dataset/e2e_synthesis_data/e2e2/map.json'

    # args.image = '/opt/dataset/e2e_synthesis_data/e2e/fisheye'
    args.image = '/opt/dataset/e2e_synthesis_data/e2e2/fisheye'

    args.draw_2d_box = False
    args.draw_3d_box = True

    # args.save_dir = '/opt/dataset/e2e_synthesis_data/e2e/prj2_save'
    # args.save_dir = '/opt/dataset/e2e_synthesis_data/e2e/prj3d_box_save'
    # args.save_dir = '/opt/dataset/e2e_synthesis_data/e2e/prj3d_box_save_ori'
    args.save_dir = '/opt/dataset/e2e_synthesis_data/e2e2/prj3d_box_save_ori'

    # main(args)
    # main2(args)
    main3(args)
