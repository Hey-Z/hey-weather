# Data Filter
a data deduplication method based on similarity comparison

## Modules
* SimCLR encoder : encoder.py
* CoreSet sample : sampler.py

## Structure
* activelearninggoogle :  sampling strategy
* checkpoint :  encoder model file
* data :  demo data
* lightly :  active learning module
* copy_select_files.py copy selected files from source directory to destination directory
* dedup.py: deduplicate main file of this project
* encoder.py :  encode images to features
* README.md
* run.sh
* sampler.py :  sampling images based on features similarity

## Installation
### Requirements
The codes are tested in the following environment:
* Linux (tested on Ubuntu 18.04)
* Python 3.8.16
* PyTorch 1.8.1+cu111
* CUDA 11.1 or higher

### Pre-Install
* pip install -r requirements.txt

## Image
docker pull p.cargo.io/release2/data_dedup:v1.0

## Run
python dedup.py --ratio=0.3 --input_path="data/" --output_path="res/" --save

[//]: # (bash run.sh /path/to/your/images /path/to/save/results sample_ratio&#40;e.g: 0.1/0.3/0.5/0.7 ...&#41;)