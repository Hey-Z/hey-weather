# OHOMS-PCDet - 点云OD在线难例挖掘与合成筛选-基于OpenPCDet框架

## Introduction
- 点云3D目标检测
- 包括数据预处理、数据集划分、模型训练、模型评估、报告生成和模型更新等功能

## 从数据库中拉取数据
根据tabel_name和condition从metabase拉取数据，根据batch保存到本地不同的sequence文件夹中
```
cd AutoPCDet &&
python download_files.py --tabel_name --condition --save_dir
```
- tabel_name: 数据库表名称
- condition：获取数据的条件，e.g. "delivery_date = '20240109' and batch_id = '110' and sensor_count >= 7 and update_time >= date('2024-01-09')"
- save_dir：数据保存的文件夹路径
 
## 数据预处理
### dataloader数据生成
调用waymo工具，从原始数据生成OpenPCDet需要的格式（pcd-->npy，json-->pkl），生成*_processed_data文件夹，*_processed_infos_train.pkl，*_processed_infos_val.pkl，gt_database文件夹，gt_database.pkl
```
cd AutoPCDet/detection && 
python -m pcdet.datasets.pandar.pandar_dataset --cfg_file tools/cfgs/dataset_configs/demo_dataset.yaml --raw_data_tag raw_data --func create_waymo_infos
python -m pcdet.datasets.pandar.pandar_dataset --cfg_file tools/cfgs/dataset_configs/demo_dataset.yaml --raw_data_tag raw_data --func create_waymo_database
```

### 数据去重
对数据集按一定的比例（ratio）进行去重
```
cd AutoPCDet/data_filter &&
python dedup.py --ratio --input_path --output_path --save
```

### 数据筛选
利用主动学习的方法对数据集进行筛选
```
cd AutoPCDet/data_filter &&
python sampler.py --ratio --input_path --output_path --save
```

### 数据合成
```
cd AutoPCDet/data_synthesis &&
python transform_format.py --input_path --output_path
```

## 划分数据集（可选）
按照文件划分训练集和验证集（如果需要），生成保存所有frame路径的文件：train_files.txt/val_files.txt
```
cd AutoPCDet &&
python split_dataset.py --ratio
```
- ratio：训练集占整个数据集的比例

## 训练模型
在划分好的训练集上训练点云检测模型
```
cd AutoPCDet/detection/tools &&
python train.py --cfg_file cfgs/pandar_models/demo.yaml --extra_tag demo --pretrained_model model/waymo_d1.pt  # 单卡训练
bash scripts/dist_train.sh 4 --cfg_file cfgs/pandar_models/demo.yaml --extra_tag demo --pretrained_model model/waymo_d1.pt # 多卡训练
```
- cfg_file: 模型配置文件，包括类别名称，数据集配置文件，模型配置和训练配置
- extra_tag: 训练任务的额外标签，和输出结果的保存路径有关
- pretrained_model: 加载预训练模型文件的路径
- ckpt: 从该模型文件恢复训练
- batch_size/epochs: 一般在模型配置文件中设置
- workers: dataloader加载数据的worker数量
- ckpt_save_interval: 模型文件的存储间隔（每epoch）
- max_ckpt_save_num: 最大保存多少个模型文件，超出则删除保存时间最早的模型文件

## 模型评估
模型训练完成后，在划分好的验证集或者其他验证集上评估模型精度，分两步第一步评估mAP，第二部评估ATE（平均中心点误差）、ASE（平均尺度误差）、AOS（平均朝向误差）、AAE（平均分类误差）这些指标
```
cd AutoPCDet/detection/tools &&
python test.py --cfg_file cfgs/pandar_models/demo.yaml --extra_tag --ckpt model/waymo_d1.pth --eval_output_dir # 评估mAP
```
- eval_output_dir: 评估结果会保存在eval_output_dir/extra_tag目录下

```
cd AutoPCDet &&
python nuscenes_metric.py --pred_file --gt_file # 评估其他指标
```
- pred_file: 一般为上一个步骤生成，eval_output_dir/extra_tag/results.pkl
- gt_file: 一般为数据预处理时生成，data/demo_processed_data_infos_val.pkl

## 汇总结果
将模型评估的精度和其他指标汇总成表格输出
```
cd AutoPCDet &&
python summarized_results.py --waymo_result --nuscenes_result
```
- waymo_result: waymo评估代码的输出结果
- nuscenes_result: nuscenes评估代码的输出结果
