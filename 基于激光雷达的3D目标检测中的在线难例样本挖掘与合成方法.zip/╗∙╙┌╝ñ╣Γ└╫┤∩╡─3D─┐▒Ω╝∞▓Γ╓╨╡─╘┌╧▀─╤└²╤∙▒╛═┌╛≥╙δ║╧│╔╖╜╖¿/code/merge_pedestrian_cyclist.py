import argparse
import json
from tqdm import tqdm
import os
import transforms3d as tfs
import numpy as np
# from pathlib import Path
import shutil

try:
    from pcdet.utils.common_utils import create_logger
    logger = create_logger()
except:
    import logging
    logger = logging.getLogger()
    
# logger = create_logger()

class MergePedestrianCyclist(object):
    def __init__(self):
        super().__init__()
        
    def min_max(self, wheel, pede, wheel_pose):
        x_all = np.concatenate([wheel[:, 0], pede[:, 0]])
        y_all = np.concatenate([wheel[:, 1], pede[:, 1]])
        z_all = np.concatenate([wheel[:, 2], pede[:, 2]])

        xmax, xmin = max(x_all), min(x_all)
        ymax, ymin = max(y_all), min(y_all)
        zmax, zmin = max(z_all), min(z_all)

        newx = (xmin + xmax) / 2
        newy = (ymin + ymax) / 2
        newz = (zmin + zmax) / 2
        newl = xmax - xmin
        neww = ymax - ymin
        newh = zmax - zmin

        new_3D_target = newx, newy, newz, neww, newl, newh, wheel_pose[0], wheel_pose[1], wheel_pose[2]

        return new_3D_target
    
    def ego2target(self, data):
        roll, pitch, yaw = data[6:9]
        x, y, z = data[:3]

        t = [x, y, z]
        r = tfs.euler.euler2mat(roll, pitch, yaw)

        target2ego = np.eye(4)
        target2ego[:3, :3] = r
        target2ego[:3, 3] = t

        ego2target = np.linalg.inv(target2ego)

        return ego2target, target2ego
    
    def data_ego2target(self, data, ego2target_train):

        points = data[:, :3]
        one = np.ones(8)
        points = np.concatenate([points, np.array([one]).T], axis=1)

        xyz_target = (ego2target_train @ points.T).T
        xyz_target = xyz_target[:, :3]
        data_new = np.concatenate([xyz_target, np.array(data[:, 3:])], axis=1)

        return data_new
    
    def data_target2ego(self, data, target2ego_train):

        x, y, z = data[:3]
        a = [x, y, z, 1]
        xyz_target = target2ego_train @ a
        xyz_target = xyz_target[:3]
        data_ego = np.concatenate((xyz_target, list(data[3:])), axis=0)

        return data_ego
            
    def calculate_box_corners(self, bbox):
        x, y, z, width, length, height, roll, pitch, yaw = bbox
        # 定义3D框的半尺寸
        half_length = length / 2
        half_width = width / 2
        half_height = height / 2

        # 计算3D框的旋转矩阵
        rotation_matrix = np.array([
            [np.cos(yaw) * np.cos(pitch), -np.sin(yaw) * np.cos(roll) + np.cos(yaw) * np.sin(pitch) * np.sin(roll), np.sin(yaw) * np.sin(roll) + np.cos(yaw) * np.sin(pitch) * np.cos(roll)],
            [np.sin(yaw) * np.cos(pitch), np.cos(yaw) * np.cos(roll) + np.sin(yaw) * np.sin(pitch) * np.sin(roll), -np.cos(yaw) * np.sin(roll) + np.sin(yaw) * np.sin(pitch) * np.cos(roll)],
            [-np.sin(pitch), np.cos(pitch) * np.sin(roll), np.cos(pitch) * np.cos(roll)]
        ])

        # 计算框的8个顶点坐标（相对于框中心）
        box_vertices_relative = np.array([
            [-half_length, -half_width, -half_height],
            [-half_length, half_width, -half_height],
            [half_length, half_width, -half_height],
            [half_length, -half_width, -half_height],
            [-half_length, -half_width, half_height],
            [-half_length, half_width, half_height],
            [half_length, half_width, half_height],
            [half_length, -half_width, half_height]
        ])

        # 应用旋转并平移到中心点位置
        rotated_box_vertices = np.dot(box_vertices_relative, rotation_matrix.T)
        translated_box_vertices = rotated_box_vertices + np.array([x, y, z])

        return translated_box_vertices, [roll, pitch, yaw]
    
    def fuse(self, same_obj):
        instance_id, annos = same_obj[0], same_obj[1]
        if annos[0]['category'] == 'TwoWheels':
            wheel_anno = annos[0]
            pede_anno = annos[1]
        else:
            wheel_anno = annos[1]
            pede_anno = annos[0]

        wheel = wheel_anno['PC_3D'][:9]
        pede = pede_anno['PC_3D'][:9]

        ego_target, target_ego = self.ego2target(wheel)
        wheel_corner, wheel_pose = self.calculate_box_corners(wheel)
        pede_corner, pede_pose = self.calculate_box_corners(pede)

        wheel_corner_target = self.data_ego2target(wheel_corner, ego_target)
        pede_corner_target = self.data_ego2target(pede_corner, ego_target)

        new_target = self.min_max(wheel_corner_target, pede_corner_target, wheel_pose)
        new_ego = self.data_target2ego(new_target, target_ego)

        wheel_anno['PC_3D'] = new_ego.tolist()

        return wheel_anno
    
    def fuse_batch(self, sequences, data_dir):
        count = 0
        for sequence in tqdm(sequences):
            json_dir = os.path.join(data_dir, sequence)
            frames = [file for file in os.listdir(json_dir) if file.split('.')[-1] == 'json']

            for frame in frames:
                vis_instance_ids = {}
                same_instance_ids = []
                with open(os.path.join(json_dir, frame)) as fp:
                    contents = json.load(fp)

                    meta = contents['meta']
                    new_contents = {'meta': meta, 'annotations': []}

                    annotations = contents['annotations']
                    for i, annotation in enumerate(annotations):
                        if annotation['labeling_type'] != 'PC_3D':
                            continue

                        if annotation['category'] == 'TwoWheels' or annotation['category'] == 'Pedestrian':
                            instance_id = annotation['property']['instance_id']
                            if instance_id in vis_instance_ids:
                                vis_instance_ids[instance_id].append(annotation)
        #                         print('bingo!, ', os.path.join('raw_data', cur_train, cur_json))
                            else:
                                vis_instance_ids[instance_id] = [annotation]
                        else:
                            new_contents['annotations'].append(annotation)

                    for k, v in vis_instance_ids.items():
                        if len(v) == 2:
                            same_instance_ids.append((k, v))
                        elif len(v) == 1:
                            if v[0]['category'] == 'TwoWheels' or v[0]['category'] == 'Pedestrian':
                                new_contents['annotations'].append(v[0])

                    if len(same_instance_ids) > 0:
                        count += 1
                        for same in same_instance_ids:
                            # 合并两个类别
                            new_annotation = self.fuse(same)
                            new_contents['annotations'].append(new_annotation)
                    else:
                        # 如果没有要合并的实例的话，直接复制一份原始标注，便于后续处理
                        new_contents = contents
                    
                    # 将原来的json备份成ori
                    shutil.copy(os.path.join(json_dir, frame), os.path.join(json_dir, frame.split('.')[0] + '_ori.json'))
                    # 保存合并两轮车和行人后新的json
#                     new_json = frame.split('.')[0] + '_merge' + '.json'
                    new_json = frame
                    with open(os.path.join(json_dir, new_json), 'w') as fp:
                        json.dump(new_contents, fp)
        return count
    
    def fuse_from_file(self, file_path):
        with open(file_path, 'r') as fp:
            all_seqs = fp.readlines()
            all_seqs = [seq.strip().split('.')[0] for seq in all_seqs]
            
        self.fuse_batch(all_seqs)

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='arg parser')
#     parser.add_argument('--data_path', type=str, help='tabel name in meta base')
    parser.add_argument('--data_dir', type=str, help='data dir of ')
    
    args = parser.parse_args()
    
    logger.info('**********************Start Merge Pedestrian and Cyclist**********************')

    all_seqs = []
#     with open(args.data_path) as fp:
#         batch_frames = fp.readlines()
#         for bf in batch_frames:
#             batch_id = bf.split()[0]
#             if batch_id not in all_seqs:
#                 all_seqs.append(batch_id)
                
    sequences = os.listdir(args.data_dir)
    sequences = [seq.strip() for seq in sequences if '.ipynb' not in seq]
    all_seqs.extend(sequences)
    
    logger.info(f'all sequences: {len(all_seqs)}')
    
    merge = MergePedestrianCyclist()
    count = merge.fuse_batch(all_seqs, data_dir=args.data_dir)
    
    logger.info(f'merged sequences: {count}')
    