import os
import argparse
import json

from pcdet.utils.common_utils import create_logger

logger = create_logger()

def main(waymo_res, nuscenes_res, save_dir):
    with open(waymo_res) as f1:
        waymo_infos = json.load(f1)
        
    with open(nuscenes_res) as f2:
        nuscenes_infos = json.load(f2)
        
    


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='arg parser')
    parser.add_argument('--waymo_results', type=str, default=None, help='')
    parser.add_argument('--nuscenes_results', type=str, default=None, help='')
    parser.add_argument('--output_dir', type=str, default=None, help='save directory')
    
    args = parser.parse_args()
    
    logger.info('**********************Start Summarize Results**********************')
    
    main(args.waymo_results, args.nuscenes_results, args.output_dir)
        
    logger.info(f'summarrized results are saved to: {args.output_dir}')