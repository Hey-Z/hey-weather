点云OD自动化迭代pipeline：
1. 从metabase下载数据，根据tabel_name和condition从metabase拉去数据，根据batch保存到本地不同的sequence文件夹中
   示例：python download_file.py --tabel_name --condition --save_dir
   tabel_name: metabase表名称,labelresult_image_bevod(人工标注)/labelresult_image_bevod_autofix(自动标注人工修复)
   condition：获取数据的条件，e.g. "delivery_date = '20240109' and batch_id = '110' and sensor_count >= 7 and update_time >= date('2024-01-09')"
   save_dir：数据保存的文件夹路径

2. 合并两轮车和行人,对json文件里的cyclist和pedestrian类别做逻辑上的合并，并将合并后的结果保存到原json中，在此之前原json会备份为原_ori.json
   示例：python merge_pedestrian_cyclist.py --data_dir
   data_dir: 原始数据的文件夹路径

3. split_train_val，划分训练集和验证集（如果需要），生成两种文件，一种是保存batch名字的文件：train.txt/val.txt， 另一种是保存所有frame路径的文件：train_files.txt/val_files.txt
   示例: python split_train_val.py --ratio
   ratio：训练集占整个数据集的比例
   
4. 调用waymo工具，从原始数据生成OpenPCDet需要的格式（pcd-->npy，json-->pkl）
   python -m pcdet.datasets.pandar.pandar_dataset.py --cfg_file tools/cfgs/dataset_configs/tmp_dataset.yaml --raw_data_tag demo_data --processed_data_tag demo_processed_data --func create_waymo_infos
   python -m pcdet.datasets.pandar.pandar_dataset.py --cfg_file tools/cfgs/dataset_configs/tmp_dataset.yaml --raw_data_tag demo_data --processed_data_tag demo_processed_data --func create_waymo_database
   参数说明：
   cfg_file: dataset的配置文件；
   raw_data_tag: 原始数据文件夹名称
   processed_data_tag: 处理完成后的数据保存文件夹名称
   func: 调用函数名称，create_waymo_infos/生成训练数据和真值, create_waymo_database/根据train的真值生成目标采样
 

   
