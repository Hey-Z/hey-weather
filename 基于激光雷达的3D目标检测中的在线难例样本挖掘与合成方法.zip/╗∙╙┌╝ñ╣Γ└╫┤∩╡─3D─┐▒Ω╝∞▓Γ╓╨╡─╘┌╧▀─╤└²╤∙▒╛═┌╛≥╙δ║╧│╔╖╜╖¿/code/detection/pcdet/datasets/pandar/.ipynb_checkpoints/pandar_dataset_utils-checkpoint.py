# OpenPCDet PyTorch Dataloader and Evaluation Tools for Waymo Open Dataset
# Reference https://github.com/open-mmlab/OpenPCDet
# Written by Shaoshuai Shi, Chaoxu Guo
# All Rights Reserved 2019-2020.

import open3d
import json
import os
import pickle
import numpy as np
from ...utils import common_utils
import tensorflow as tf
from waymo_open_dataset.utils import frame_utils, transform_utils, range_image_utils
from waymo_open_dataset import dataset_pb2
from scipy.spatial.transform import Rotation as R

try:
    tf.enable_eager_execution()
except:
    pass

WAYMO_CLASSES = ['unknown', 'Vehicle', 'Pedestrian', 'Sign', 'Cyclist']
# WAYMO_CLASSES = ['unknown', 'Vehicle', 'Pedestrian', 'Cyclist']

class_map = {
    '': 'unknown',
    'Unknow': 'unknown',
    'Unknown': 'unknown',
    'Cyclist': 'Cyclist',
    'MotorVehicle': 'Vehicle', 
    'Two-wheels': 'Cyclist',
    'Pedestrian': 'Pedestrian',
    'TwoWheels': 'Cyclist',
    'Tricycle': 'Vehicle',
    'PassengerCar': 'Vehicle',
    'CommercialBus': 'Vehicle',
    'CommercialTruck': 'Vehicle', 
    'Bicycle': 'Cyclist', 
    'OtherVehicle': 'Vehicle', 
    'Adult': 'Pedestrian', 
    'Children': 'Pedestrian',  
    'Child': 'Pedestrian',  
    'CombinationVehicle': 'Vehicle',
    'WarningPost': 'Barrier',
    'SpecialVehicle': 'Vehicle', 
    'Motorbike': 'Cyclist',
    'ConstructionGuideMark': 'Barrier',
    'AntiCollisionDrum': 'Barrier',
    'PassengerCar ': 'Vehicle',
    'Police': 'Pedestrian',
    'CommercialBus ': 'Vehicle',
    'TriangleSign': 'Barrier',
    'Tyre': 'Barrier',
    'Box': 'Barrier',
    'ConstructionRoadblock': 'Barrier',
    'Trailer': 'Vehicle',
    'MaintenanceBadge': 'Barrier',
    'WaterHorse': 'Barrier',
    'Cone': 'Barrier',
    'Van': 'Vehicle',
    'SpecialCar': 'Vehicle',
    'SpecialTruck': 'Vehicle',
    'SpecialTwoWheels': 'Cyclist',
    'SpecialBus': 'Vehicle',
    'BrakeLight': 'Barrier',
    'LeftTurnLight': 'Barrier',
}

def transfor_pandar128_name_to_waymo_name(name):
    waymo_name = 'unknown'
    waymo_id = 0
    if name in ['Vehicle', 'VEHICLE', 'vehicle']:
        waymo_name = 'Vehicle'
        waymo_id = 1
    elif name in ['Pedestrian', 'PEDESTRIAN', 'pedestrian']:
        waymo_name = 'Pedestrian'
        waymo_id = 2
    elif name in ['Barrier', 'BARRIER', 'barrier']:
        waymo_name = 'Sign'
        waymo_id = 3
    elif name in ['Cyclist', 'CYCLIST',  'cyclist']:
        waymo_name = 'Cyclist'
        waymo_id = 4

    return waymo_name, waymo_id

def get_num_points_in_gt(cloud_points, object_bboxes):
    dim_ind = np.array([
        [1, -1, 1],
        [1, 1, 1],
        [-1, 1, 1],
        [-1, -1, 1],
        [1, -1, -1],
        [1, 1, -1],
        [-1, 1, -1],
        [-1, -1, -1]
    ]) * 0.5

    num_points_in_gt = []
    difficulty = []
    for obj_bbox in object_bboxes:
        box_center = obj_bbox[:3]
        box_dim = obj_bbox[3:6]
        box_rot = obj_bbox[6:]

        ori_corners = dim_ind * box_dim
        cloud_points_copy = cloud_points.copy()
        cloud_points_copy -= box_center
        box_rot_mat = R.from_euler('xyz', [0, 0, box_rot[-1]], degrees=False).as_matrix()
        cloud_points_copy = np.matmul(cloud_points_copy, np.linalg.inv(box_rot_mat).T)
        # ori_corners = np.matmul(box_rot_mat, ori_corners.T)
        # corner_points = ori_corners.T + box_center

        box_range = np.array([
            ori_corners[:, 0].max(), ori_corners[:, 0].min(),
            ori_corners[:, 1].max(), ori_corners[:, 1].min(),
            ori_corners[:, 2].max(), ori_corners[:, 2].min()
        ])

        mask = (cloud_points_copy[:, 0] < box_range[0]) & (cloud_points_copy[:, 0] > box_range[1]) & \
               (cloud_points_copy[:, 1] < box_range[2]) & (cloud_points_copy[:, 1] > box_range[3]) & \
               (cloud_points_copy[:, 2] < box_range[4]) & (cloud_points_copy[:, 2] > box_range[5])

        num_points = np.sum(mask)
        num_points_in_gt.append(num_points)
        if 0 <= num_points <= 5:  # fixbug: 原来的标注文件中有点数等于0的目标
            difficulty.append(2)
        else:
            difficulty.append(1)

    return np.array(num_points_in_gt), np.array(difficulty)

def filter_empty_in_gt(annotations):
    gt_points = annotations['num_points_in_gt']
    mask = gt_points > 0
    for k, v in annotations.items():
        annotations[k] = v[mask]
    return annotations

# difficulty 2 with points < 5;
def generate_labels(point_clouds, laser_labels):
    obj_name, _, dimensions, locations, heading_angles = [], [], [], [], []
    tracking_difficulty, speeds, accelerations, obj_ids = [], [], [], []

    for i in range(len(laser_labels)):
        cur_label = laser_labels[i]
        
        if cur_label['labeling_type'] != 'PC_3D':
            continue

        if 'is_tight' in cur_label['property']:
            is_tight = cur_label['property']['is_tight']
            if is_tight == 0:
                continue
        
        if cur_label['sub_category'] is None:
            box_name = class_map[cur_label['category']]
        elif len(cur_label['sub_category']) == 0:
            box_name = class_map[cur_label['category']]
        else:
#             if i <= len(laser_labels) - 2:
            if cur_label['sub_category'] == 'CommercialTruck' and i <= len(laser_labels) - 2:  # 比较cur_label和next_label的instance_id是否相同
                if cur_label['property']['instance_id'] == laser_labels[i + 1]['property']['instance_id']:
                    continue
                else:
                    box_name = class_map[cur_label['sub_category']]
            elif cur_label['sub_category'] == 'Trailer':
                continue
            else:
                box_name = class_map[cur_label['sub_category']]
            
        waymo_name, waymo_id = transfor_pandar128_name_to_waymo_name(box_name)
        bbox_3d = cur_label['PC_3D']
        box_size = bbox_3d[3:6]
        if ((box_name=='Cyclist') and np.any(np.array(box_size)>3)):
            continue
        
        loc = [bbox_3d[0], bbox_3d[1], bbox_3d[2]]
        heading_angles.append(bbox_3d[8])
        obj_name.append(waymo_name)
        # difficulty.append(1)  # todo
        tracking_difficulty.append(1)  # todo
        dimensions.append([bbox_3d[4], bbox_3d[3], bbox_3d[5]])  # l, w, h
        locations.append(loc)
        obj_ids.append(box_name)  # todo
        # num_points_in_gt.append(100)  # todo

    annotations = {}
    annotations['name'] = np.array(obj_name)
    # annotations['difficulty'] = np.array(difficulty)
    annotations['dimensions'] = np.array(dimensions)
    annotations['location'] = np.array(locations)
    annotations['heading_angles'] = np.array(heading_angles)

    annotations['obj_ids'] = np.array(obj_ids)
    annotations['tracking_difficulty'] = np.array(tracking_difficulty)
    # annotations['num_points_in_gt'] = np.array(num_points_in_gt)

    annotations = common_utils.drop_info_with_name(annotations, name='unknown')
    if annotations['name'].__len__() > 0:
        gt_boxes_lidar = np.concatenate([
            annotations['location'], annotations['dimensions'], annotations['heading_angles'][..., np.newaxis]],
            axis=1
        )
    else:
        gt_boxes_lidar = np.zeros((0, 7))
    annotations['gt_boxes_lidar'] = gt_boxes_lidar

    num_points_in_gt, difficulty = get_num_points_in_gt(point_clouds, gt_boxes_lidar)
    annotations['num_points_in_gt'] = num_points_in_gt
    annotations['difficulty'] = difficulty

    annotations = filter_empty_in_gt(annotations)  # 过滤掉点数为0的真值框
    return annotations

def convert_range_image_to_point_cloud(frame, range_images, camera_projections, range_image_top_pose, ri_index=(0, 1)):
    """
    Modified from the codes of Waymo Open Dataset.
    Convert range images to point cloud.
    Args:
        frame: open dataset frame
        range_images: A dict of {laser_name, [range_image_first_return, range_image_second_return]}.
        camera_projections: A dict of {laser_name,
            [camera_projection_from_first_return, camera_projection_from_second_return]}.
        range_image_top_pose: range image pixel pose for top lidar.
        ri_index: 0 for the first return, 1 for the second return.

    Returns:
        points: {[N, 3]} list of 3d lidar points of length 5 (number of lidars).
        cp_points: {[N, 6]} list of camera projections of length 5 (number of lidars).
    """
    calibrations = sorted(frame.context.laser_calibrations, key=lambda c: c.name)
    points = []
    cp_points = []
    points_NLZ = []
    points_intensity = []
    points_elongation = []

    frame_pose = tf.convert_to_tensor(np.reshape(np.array(frame.pose.transform), [4, 4]))
    # [H, W, 6]
    range_image_top_pose_tensor = tf.reshape(
        tf.convert_to_tensor(range_image_top_pose.data), range_image_top_pose.shape.dims
    )
    # [H, W, 3, 3]
    range_image_top_pose_tensor_rotation = transform_utils.get_rotation_matrix(
        range_image_top_pose_tensor[..., 0], range_image_top_pose_tensor[..., 1],
        range_image_top_pose_tensor[..., 2])
    range_image_top_pose_tensor_translation = range_image_top_pose_tensor[..., 3:]
    range_image_top_pose_tensor = transform_utils.get_transform(
        range_image_top_pose_tensor_rotation,
        range_image_top_pose_tensor_translation)

    for c in calibrations:
        points_single, cp_points_single, points_NLZ_single, points_intensity_single, points_elongation_single \
            = [], [], [], [], []
        for cur_ri_index in ri_index:
            range_image = range_images[c.name][cur_ri_index]
            if len(c.beam_inclinations) == 0:  # pylint: disable=g-explicit-length-test
                beam_inclinations = range_image_utils.compute_inclination(
                    tf.constant([c.beam_inclination_min, c.beam_inclination_max]),
                    height=range_image.shape.dims[0])
            else:
                beam_inclinations = tf.constant(c.beam_inclinations)

            beam_inclinations = tf.reverse(beam_inclinations, axis=[-1])
            extrinsic = np.reshape(np.array(c.extrinsic.transform), [4, 4])

            range_image_tensor = tf.reshape(
                tf.convert_to_tensor(range_image.data), range_image.shape.dims)
            pixel_pose_local = None
            frame_pose_local = None
            if c.name == dataset_pb2.LaserName.TOP:
                pixel_pose_local = range_image_top_pose_tensor
                pixel_pose_local = tf.expand_dims(pixel_pose_local, axis=0)
                frame_pose_local = tf.expand_dims(frame_pose, axis=0)
            range_image_mask = range_image_tensor[..., 0] > 0
            range_image_NLZ = range_image_tensor[..., 3]
            range_image_intensity = range_image_tensor[..., 1]
            range_image_elongation = range_image_tensor[..., 2]
            range_image_cartesian = range_image_utils.extract_point_cloud_from_range_image(
                tf.expand_dims(range_image_tensor[..., 0], axis=0),
                tf.expand_dims(extrinsic, axis=0),
                tf.expand_dims(tf.convert_to_tensor(beam_inclinations), axis=0),
                pixel_pose=pixel_pose_local,
                frame_pose=frame_pose_local)

            range_image_cartesian = tf.squeeze(range_image_cartesian, axis=0)
            points_tensor = tf.gather_nd(range_image_cartesian,
                                         tf.where(range_image_mask))
            points_NLZ_tensor = tf.gather_nd(range_image_NLZ, tf.compat.v1.where(range_image_mask))
            points_intensity_tensor = tf.gather_nd(range_image_intensity, tf.compat.v1.where(range_image_mask))
            points_elongation_tensor = tf.gather_nd(range_image_elongation, tf.compat.v1.where(range_image_mask))
            cp = camera_projections[c.name][0]
            cp_tensor = tf.reshape(tf.convert_to_tensor(cp.data), cp.shape.dims)
            cp_points_tensor = tf.gather_nd(cp_tensor, tf.where(range_image_mask))

            points_single.append(points_tensor.numpy())
            cp_points_single.append(cp_points_tensor.numpy())
            points_NLZ_single.append(points_NLZ_tensor.numpy())
            points_intensity_single.append(points_intensity_tensor.numpy())
            points_elongation_single.append(points_elongation_tensor.numpy())

        points.append(np.concatenate(points_single, axis=0))
        cp_points.append(np.concatenate(cp_points_single, axis=0))
        points_NLZ.append(np.concatenate(points_NLZ_single, axis=0))
        points_intensity.append(np.concatenate(points_intensity_single, axis=0))
        points_elongation.append(np.concatenate(points_elongation_single, axis=0))

    return points, cp_points, points_NLZ, points_intensity, points_elongation


def save_lidar_points(pcd, cur_save_path, use_two_returns=True):
    positions = pcd.point.positions.numpy()
    intensity = pcd.point.intensity.numpy()
    # 自采数据集强度进行255归一化
    intensity = intensity / 255.0
    
    points_in_NLZ_flag = -1 * np.ones((positions.shape[0], 1), dtype=np.float)
    points_elongation = np.zeros((positions.shape[0], 1), dtype=np.float)  # todo

    save_points = np.concatenate([
        positions, intensity, points_elongation, points_in_NLZ_flag
    ], axis=-1).astype(np.float32)

    num_points_of_each_lidar = [positions.shape[0]]  # todo

    np.save(cur_save_path, save_points)
    # print('saving to ', cur_save_path)
    return num_points_of_each_lidar


def process_single_sequence(sequence_file, save_path, sampled_interval, has_label=True, use_two_returns=True, update_info_only=False):
#     sequence_name = os.path.splitext(os.path.basename(sequence_file))[0]
#     sequence_dir = os.path.dirname(sequence_file)
    sequence_name = os.path.split(sequence_file)[1]
    sequence_dir = os.path.dirname(sequence_file)
    tabel_name = os.path.split(sequence_dir)[1]
    
    # print('Load record (sampled_interval=%d): %s' % (sampled_interval, sequence_name))
    if not sequence_file.exists():
        print('NotFoundError: %s' % sequence_file)
        return []

    # dataset = tf.data.TFRecordDataset(str(sequence_file), compression_type='')
    cur_save_dir = save_path / f'{tabel_name}_{sequence_name}'
    cur_save_dir.mkdir(parents=True, exist_ok=True)
    pkl_file = cur_save_dir / ('%s.pkl' % sequence_name)

#     with open(sequence_file, 'r') as fs:  # sequence_file 保存所有sequence的文件名
#         frames = fs.readlines()
#         frames = [frame.strip() for frame in frames]
        
    frames = sequence_file.rglob('*.pcd')
    frames = [os.path.splitext(os.path.basename(frame))[0] for frame in frames]

    sequence_infos = []
    if pkl_file.exists():
        sequence_infos = pickle.load(open(pkl_file, 'rb'))
        sequence_infos_old = None
        if not update_info_only:
            print('Skip sequence since it has been processed before: %s' % pkl_file)
            return sequence_infos
        else:
            sequence_infos_old = sequence_infos
            sequence_infos = []

    for cnt, frame in enumerate(frames):
        if frame == '' or frame is None:
            continue
        if cnt % sampled_interval != 0:
            continue
        # print(sequence_name, cnt)
        
        pcd = open3d.t.io.read_point_cloud(filename=os.path.join(sequence_dir, sequence_name, f'{frame}.pcd'))
        if pcd.is_empty():
            continue
            
        with open(os.path.join(sequence_dir, sequence_name, f'{frame}.json'), 'rb') as fa:  # 使用merge后的json文件
        # with open(os.path.join(sequence_dir, sequence_name+'_json', f'{frame}.json'), 'rb') as fa:  # for 3dod/test_data
            annos = json.load(fa)

        info = {}
        info['pcd_path'] = os.path.join(sequence_dir, sequence_name, f'{frame}.pcd')
        pc_info = {'num_features': 5, 'tabel_name': tabel_name, 'lidar_sequence': sequence_name, 'sample_idx': cnt, 'frame': frame}
        info['point_cloud'] = pc_info

        info['frame_id'] = tabel_name + '_' + sequence_name + ('_%04d' % cnt)
        # info['metadata'] = {
        #     'context_name': frame.context.name,
        #     'timestamp_micros': frame.timestamp_micros
        # }
        # image_info = {}
        # for j in range(5):
        #     width = frame.context.camera_calibrations[j].width
        #     height = frame.context.camera_calibrations[j].height
        #     image_info.update({'image_shape_%d' % j: (height, width)})
        # info['image'] = image_info

        # pose = np.array(frame.pose.transform, dtype=np.float32).reshape(4, 4)
        # info['pose'] = pose

        if has_label:
            laser_meta = annos['meta']
            laser_labels = annos['annotations']
            annotations = generate_labels(pcd.point.positions.numpy().copy(),
                                          laser_labels)  # 对原始annos处理得到指定格式的annotations
            info['annos'] = annotations

        if update_info_only and sequence_infos_old is not None:
            assert info['frame_id'] == sequence_infos_old[cnt]['frame_id']
            num_points_of_each_lidar = sequence_infos_old[cnt]['num_points_of_each_lidar']
        else:
            num_points_of_each_lidar = save_lidar_points(
                pcd, cur_save_dir / ('%04d.npy' % cnt), use_two_returns=use_two_returns
            )
        info['num_points_of_each_lidar'] = num_points_of_each_lidar

        sequence_infos.append(info)

    with open(pkl_file, 'wb') as f:
        pickle.dump(sequence_infos, f)

    print('Infos are saved to (sampled_interval=%d): %s' % (sampled_interval, pkl_file))
    return sequence_infos

def process_single_sequence_withfile(sequence_file, save_path, sampled_interval, has_label=True, use_two_returns=True, update_info_only=False):
    sequence_name = os.path.splitext(os.path.basename(sequence_file))[0]

    # print('Load record (sampled_interval=%d): %s' % (sampled_interval, sequence_name))
    if not sequence_file.exists():
        print('NotFoundError: %s' % sequence_file)
        return []

    dataset = tf.data.TFRecordDataset(str(sequence_file), compression_type='')
    cur_save_dir = save_path / sequence_name
    cur_save_dir.mkdir(parents=True, exist_ok=True)
    pkl_file = cur_save_dir / ('%s.pkl' % sequence_name)

    sequence_infos = []
    if pkl_file.exists():
        sequence_infos = pickle.load(open(pkl_file, 'rb'))
        has_info = True
        sequence_infos_old = None
        if not update_info_only:
            print('Skip sequence since it has been processed before: %s' % pkl_file)
            #return sequence_infos
        else:
            sequence_infos_old = sequence_infos
            sequence_infos = []

        for cnt, data in enumerate(dataset):
            if cnt % sampled_interval != 0:
                continue
            npy_file = cur_save_dir / ('%04d.npy' % cnt)
            if npy_file.exists():
                print('Skip frame since it has been processed before: %s' % npy_file)
                continue
            else:
                # print(sequence_name, cnt)
                frame = dataset_pb2.Frame()
                frame.ParseFromString(bytearray(data.numpy()))
                num_points_of_each_lidar = save_lidar_points(
                    frame, cur_save_dir / ('%04d.npy' % cnt), use_two_returns=use_two_returns
                )
    else:
        for cnt, data in enumerate(dataset):
            if cnt % sampled_interval != 0:
                continue
            # print(sequence_name, cnt)
            frame = dataset_pb2.Frame()
            frame.ParseFromString(bytearray(data.numpy()))

            info = {}
            pc_info = {'num_features': 5, 'lidar_sequence': sequence_name, 'sample_idx': cnt}
            info['point_cloud'] = pc_info

            info['frame_id'] = sequence_name + ('_%03d' % cnt)
            info['metadata'] = {
                'context_name': frame.context.name,
                'timestamp_micros': frame.timestamp_micros
            }
            image_info = {}
            for j in range(5):
                width = frame.context.camera_calibrations[j].width
                height = frame.context.camera_calibrations[j].height
                image_info.update({'image_shape_%d' % j: (height, width)})
            info['image'] = image_info

            pose = np.array(frame.pose.transform, dtype=np.float32).reshape(4, 4)
            info['pose'] = pose

            if has_label:
                annotations = generate_labels(frame, pose=pose)
                info['annos'] = annotations

            if update_info_only and sequence_infos_old is not None:
                assert info['frame_id'] == sequence_infos_old[cnt]['frame_id']
                num_points_of_each_lidar = sequence_infos_old[cnt]['num_points_of_each_lidar']
            else:
                num_points_of_each_lidar = save_lidar_points(
                    frame, cur_save_dir / ('%04d.npy' % cnt), use_two_returns=use_two_returns
                )
            info['num_points_of_each_lidar'] = num_points_of_each_lidar

            sequence_infos.append(info)

        with open(pkl_file, 'wb') as f:
            pickle.dump(sequence_infos, f)

        print('Infos are saved to (sampled_interval=%d): %s' % (sampled_interval, pkl_file))
    return sequence_infos


