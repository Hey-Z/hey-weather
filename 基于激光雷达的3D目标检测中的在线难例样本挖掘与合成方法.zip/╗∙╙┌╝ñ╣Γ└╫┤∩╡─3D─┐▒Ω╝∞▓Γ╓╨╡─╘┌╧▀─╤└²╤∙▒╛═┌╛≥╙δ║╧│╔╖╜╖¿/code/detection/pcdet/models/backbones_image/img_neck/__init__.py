from .generalized_lss import GeneralizedLSSFPN
__all__ = {
    'GeneralizedLSSFPN':GeneralizedLSSFPN,
}