'''
ATE: 平均平移誤差，中心點的歐氏距離
ASE：平均尺度誤差，對齊之後的3DIOU, 1-IoU
AOE：平均方向誤差，目標好和gt之間的最小yaw角
AOS：加權方向和真值方向之間的餘弦距離
AAE: 平均属性误差，1-acc，acc为类别分类准确度
'''

import os
import numpy as np
import torch
# import open3d
from pcdet.ops.iou3d_nms.iou3d_nms_utils import boxes_iou3d_gpu
from pcdet.utils.common_utils import create_logger
import pickle
import json
from tqdm import tqdm
from pyquaternion import Quaternion
from scipy.spatial.transform import Rotation as R
import argparse

import sys
sys.path.insert(0, '../')

logger = create_logger()
logger.info('**********************Start Nuscenes Eval**********************')

class Metrics:
    def __init__(self, used_classes=['Vehicle', 'Pedestrian', 'Cyclist'], name2cls={'Vehicle': 1, 'Pedestrian': 2, 'Cyclist': 3}, cls2name={1: 'Vehicle', 2: 'Pedestrian', 3: 'Cyclist'}):
        super().__init__()
        
        self.used_classes = used_classes
        self.name2cls = name2cls
        self.cls2name = cls2name
        
        self.mATE = 0
        self.mASE = 0
        self.mAOE = 0
        self.mAAE = 0
        
        self.ate = {}
        self.ase = {}
        self.aoe = {}
        self.aae = {}
        
        self.cur_ate = []
        self.cur_ase = []
        self.cur_aoe = []
        self.cur_aae = []
        
    def match_pred_and_gt(self, pred, gt):
        '''
            preds: dict, {'name', 'score', 'boxes_lidar', 'pred_labels', 'frame_id', 'metadata'}
            gt: dict, {'point_cloud', 'frame_id', 'annos': {'name', 'dimensions', 'location', 'heading_angles', 'obj_ids', 'tracking_difficulty', 'gt_boxes_lidar', 'num_points_in_gt', 'difficulty'}, 'num_points_of_each_lidar'}
        '''
#         pred_labels = pred.get('pred_labels', None)
        pred_names = pred.get('name', None)
        pred_labels = [self.name2cls[p] for p in pred_names]
        pred_labels = np.array(pred_labels, dtype=np.int64)
        
        pred_boxes = pred.get('boxes_lidar', None)
        pred_scores = pred.get('score', None)
        
        assert len(pred_labels) == len(pred_boxes) == len(pred_scores)
        
        gt_names = gt['annos']['name']
        gt_boxes = gt['annos']['gt_boxes_lidar']
        
        # 对gt进行过滤，保留used_classes
        inds = [i for i, x in enumerate(gt_names) if x in self.used_classes]
        inds = np.array(inds, dtype=np.int64)
        gt_names = gt_names[inds]
        gt_boxes = gt_boxes[inds]
        gt_labels = [self.name2cls[l] for l in gt_names]
        gt_labels = np.array(gt_labels, dtype=np.int64)
        
        assert len(gt_names) == len(gt_boxes) == len(gt_labels)
        
        if pred_labels is None or len(pred_labels) == 0 or len(gt_boxes) == 0:
            return None, None, None, None, None, None, None
        
        # 按score从大到小对pred进行排序
        mask = np.argsort(pred_scores)[::-1]
        pred_scores = pred_scores[mask]
        pred_labels = pred_labels[mask]
        pred_boxes = pred_boxes[mask]
        
#         import pdb; pdb.set_trace()
        # 计算pred_box和gt_box的3d iou
        try:
            ious = boxes_iou3d_gpu(torch.tensor(pred_boxes).float().cuda(), torch.tensor(gt_boxes).float().cuda())
        except Exception as e:
            print(e)
            print(pred_boxes.shape, 'vs', gt_boxes.shape)
            return None, None, None, None, None, None, None
            
        ious = ious.cpu().numpy()
        
        try:
            argmax_ious = np.argmax(ious, axis=1)  # 可以多个pred对一个gt
        except Exception as e:
            print(f'ERROR!!!!!', pred_labels, gt_labels, ious)
            return None, None, None, None, None, None, None
        
        matched_gt = np.zeros(len(gt_boxes))  # already matched gt
        matched_by_iou_gt = np.zeros(len(gt_boxes))
        matches = {}
        matches_by_iou = {}
        for i, argmax in enumerate(argmax_ious):
            if ious[i][argmax] > 0 and matched_gt[argmax] == 0 and pred_labels[i] == gt_labels[argmax]:
                matches[i] = argmax
                matched_gt[argmax] = 1
            else:
                matches[i] = None
                
            if ious[i][argmax] > 0 and matched_by_iou_gt[argmax] == 0:
                matches_by_iou[i] = argmax
                matched_by_iou_gt[argmax] = 1
            else:
                matches_by_iou[i] = None
                
        return pred_boxes, pred_labels,gt_boxes, gt_names, matches, matches_by_iou, ious
    
    def calculate_distance(self, box1, box2):
        xyz1 = box1[:3]
        xyz2 = box2[:3]
        l1, w1, h1 = box1[3:6]
        l2, w2, h2 = box2[3:6]
        head1 = box1[6]
        head2 = box2[6]
        center_dis = np.sqrt(np.sum(xyz1 - xyz2) ** 2)
        l_dis = np.sqrt(np.sum(l1 - l2) **2)
        w_dis = np.sqrt(np.sum(w1 - w2) ** 2)
        h_dis = np.sqrt(np.sum(h1 - h2) ** 2)
        head_dis = np.abs(head1 - head2)
        
        return center_dis, l_dis, w_dis, h_dis, head_dis
    
    def get_ate(self, pred_boxes, pred_labels, gt_boxes, matches):
        ate = dict()
        for i, cur_class in enumerate(self.used_classes):
            cur_ate = []
            for k, v in matches.items():
                if self.cls2name[pred_labels[k]] == cur_class:
                    if v is not None:
                        x1, y1, z1 = pred_boxes[k][:3]
                        x2, y2, z2 = gt_boxes[v][:3]
                        cur_ate.append(np.sqrt((x1 - x2) **2 + (y1 - y2)**2 + (z1 - z2)**2))
                        
            if len(cur_ate) == 0:
                ate[cur_class] = None
            else:
                ate[cur_class] = np.sum(cur_ate) / len(cur_ate)  # 每一帧ate，分类别
            
        self.cur_ate.append(ate)  # 每一帧的ate
        
    def scale_iou(self, box1, box2):
        size1 = box1[[1, 0, 2]]
        size2 = box2[[1, 0, 2]]
        min_whl = np.minimum(size1, size2)
        volume1 = np.prod(size1)
        volume2 = np.prod(size2)
        intersection = np.prod(min_whl)
        union = volume1 + volume2 - intersection
        iou = intersection / union
        return iou
        
    def get_ase(self, pred_boxes, pred_labels, gt_boxes, matches):
        ase = dict()
        box1 = pred_boxes.copy()
        box2 = gt_boxes.copy()
#         box1[:, :3] = 0
#         box2[:, :3] = 0
#         box1[:, 6] = 0
#         box2[:, 6] = 0
        ious = boxes_iou3d_gpu(torch.tensor(box1).float().cuda(), torch.tensor(box2).float().cuda())
        ious = ious.cpu().numpy()
        
        for cur_class in self.used_classes:
            cur_ase = []
            for k, v in matches.items():
                if self.cls2name[pred_labels[k]] == cur_class:
                    if v is not None:
                        cur_ase.append(1 - self.scale_iou(gt_boxes[v][3:6], pred_boxes[k][3:6]))
            
            if len(cur_ase) == 0:
                ase[cur_class] = None
            else:
                ase[cur_class] = np.sum(cur_ase) / len(cur_ase)
        
        self.cur_ase.append(ase)  # 每一帧的ase
        
    def quaternion_yaw(self, q: Quaternion) -> float:
        v = np.dot(q.rotation_matrix, np.array([1, 0, 0]))
        yaw = np.arctan2(v[1], v[0])
        return yaw

    def angle_diff(self, x: float, y: float, period: float) -> float:
        diff = (x - y + period / 2) % period - period / 2
        if diff > np.pi:
            diff = diff - (2 * np.pi)
        return diff

    def yaw_diff(self, gt_box, eval_box, period: float = 2*np.pi) -> float:
        
        gt_rot_mat = R.from_euler('xyz', [0,0,gt_box[6]],degrees=False).as_matrix()
        gt_rot_q = Quaternion(matrix=gt_rot_mat)
        
        pred_rot_mat = R.from_euler('xyz', [0, 0, eval_box[6]], degrees=False).as_matrix()
        pred_rot_q = Quaternion(matrix=pred_rot_mat)
        
        yaw_gt = self.quaternion_yaw(gt_rot_q)
        yaw_est = self.quaternion_yaw(pred_rot_q)

        return abs(self.angle_diff(yaw_gt, yaw_est, period))
        
    def get_aoe(self, pred_boxes, pred_labels, gt_boxes, matches):
        aoe = dict()
        for cur_class in self.used_classes:
            cur_aoe = []
            for k, v in matches.items():
                if self.cls2name[pred_labels[k]] == cur_class:
                    if v is not None:
                        cur_aoe.append(self.yaw_diff(gt_boxes[v], pred_boxes[k], period=2*np.pi))
#                         cur_aoe.append(np.abs(pred_boxes[k][6] - gt_boxes[v][6]))
                        
            if len(cur_aoe) == 0:
                aoe[cur_class] = None
            else:
                aoe[cur_class] = np.sum(cur_aoe) / len(cur_aoe)
        
        self.cur_aoe.append(aoe)
        
    def get_aae(self, pred_labels, gt_names, matches):
        aae = dict()
        for cur_class in self.used_classes:
            tp = []
            for k, v in matches.items():
                if self.cls2name[pred_labels[k]] == cur_class:
                    if v is not None:
                        if gt_names[v] == cur_class:
                            tp.append(1)
                        else:
                            tp.append(0)
            
            if len(tp) == 0:
                aae[cur_class] = None
            else:
                aae[cur_class] = 1.0 - np.sum(tp) / len(tp)
        
        self.cur_aae.append(aae)
        
    def eval(self, preds, gts):
        assert len(preds) == len(gts), f'{len(preds)} vs. {len(gts)}'  # 预测帧数和真值帧数相等
        
        for pred, gt in tqdm(zip(preds, gts), total=len(preds)):
#             import pdb; pdb.set_trace()
            pred_boxes, pred_labels, gt_boxes, gt_names, matches, matches_by_iou, ious = self.match_pred_and_gt(pred, gt)
            if pred_boxes is None or len(pred_boxes) == 0:
                continue
            self.get_ate(pred_boxes, pred_labels, gt_boxes, matches)
            self.get_ase(pred_boxes, pred_labels, gt_boxes, matches)
            self.get_aoe(pred_boxes, pred_labels, gt_boxes, matches)
            self.get_aae(pred_labels, gt_names, matches_by_iou)
            
    def _summ(self, cur_type):
        count = [0, 0, 0]
        cur_v = 0
        cur_p = 0
        cur_c = 0
        for cur in cur_type:
            v, p, c = cur['Vehicle'], cur['Pedestrian'], cur['Cyclist']
            if v is not None:
                cur_v += v
                count[0] += 1
            if p is not None:
                cur_p += p
                count[1] += 1
            if c is not None:
                cur_c += c
                count[2] += 1
        return cur_v / count[0], cur_p / count[1], cur_c / count[2]
            
    def summary(self):
        for cur_type in ['ate', 'ase', 'aoe', 'aae']:
            if cur_type == 'ate':
                v, p, c = self._summ(self.cur_ate)
                self.ate['Vehicle'] = v
                self.ate['Pedestrian'] = p
                self.ate['Cyclist'] = c
                self.mATE = (v + p + c) / 3
                
            elif cur_type == 'ase':
                v, p, c = self._summ(self.cur_ase)
                self.ase['Vehicle'] = v
                self.ase['Pedestrian'] = p
                self.ase['Cyclist'] = c
                self.mASE = (v + p + c) / 3
                
            elif cur_type == 'aoe':
                v, p, c = self._summ(self.cur_aoe)
                self.aoe['Vehicle'] = v
                self.aoe['Pedestrian'] = p
                self.aoe['Cyclist'] = c
                self.mAOE = (v + p + c) / 3
                
            elif cur_type == 'aae':
                v, p, c = self._summ(self.cur_aae)
                self.aae['Vehicle'] = v
                self.aae['Pedestrian'] = p
                self.aae['Cyclist'] = c
                self.mAAE = (v + p + c) / 3

def main(pred_file, gt_file):
#     pred_file = 'data/bevod_manu_autofix_e13.pkl'
#     gt_file = 'data/bevod_processed_data_v0_5_0_infos_val.pkl'

    with open(pred_file, 'rb') as f1:
        preds = pickle.load(f1)

    preds = sorted(preds, key=lambda x: x['frame_id'])
    logger.info(f'preds: {len(preds)}')
    
    with open(gt_file, 'rb') as f2:
        gts = pickle.load(f2)

    gts = sorted(gts, key=lambda x: x['frame_id'])
    logger.info(f'gts: {len(gts)}')
    
    metric = Metrics()
    metric.eval(preds, gts)
    metric.summary()
    
    eval_res = {}
    ate, mate = metric.ate, metric.mATE
    ase, mase = metric.ase, metric.mASE
    aoe, maoe = metric.aoe, metric.mAOE
    aae, maae = metric.aae, metric.mAAE
    for cat in ['Vehicle', 'Pedestrian', 'Cyclist']:
        eval_res[cat]= {
            'ate': ate[cat],
            'ase': ase[cat],
            'aoe': aoe[cat],
            'aae': aae[cat]
        }
    eval_res['summary'] = {
        'mATE': mate,
        'mASE': mase,
        'mAOE': maoe,
        'mAAE': maae
    }
    
    return eval_res

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='arg parser')
    parser.add_argument('--pred_file', type=str, help='predict file path')
    parser.add_argument('--gt_file', type=str, help='ground truth file path')
    parser.add_argument('--eval_output_dir', type=str, help='')
    parser.add_argument('--extra_tag', type=str, default='default', help='')
    
    args = parser.parse_args()
    
    res = main(args.pred_file, args.gt_file)
    
    eval_output_dir = os.path.join(args.eval_output_dir, args.extra_tag)
    if not os.path.exists(eval_output_dir):
        os.makedirs(eval_output_dir, exist_ok=True)
    
    logger.info(f'save nuscenes eval results to: {eval_output_dir}')
    with open(os.path.join(eval_output_dir, 'nu_result.json'), 'w') as fp:
        json.dump(res, fp)
    