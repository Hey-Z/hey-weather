import os
import subprocess

from setuptools import find_packages, setup
from torch.utils.cpp_extension import BuildExtension, CUDAExtension

def make_cuda_ext(name, module, sources):
    cuda_ext = CUDAExtension(
        name='%s.%s' % (module, name),
        sources=[os.path.join(*module.split('.'), src) for src in sources]
    )
    return cuda_ext


if __name__ == '__main__':
    version = '0.1.0+%s'

    setup(
        name='data_process',
        version=version,
        description='The 3d object detection module of point cloud framework',
        install_requires=[
            'numpy',
            'torch',
            'numba',
            'tensorboardX',
            'easydict',
            'pyyaml'
        ],
        author='PJLab-ADLab',
        license='Apache License 2.0',
        packages=["datasets"],
        cmdclass={'build_ext': BuildExtension},
    )
